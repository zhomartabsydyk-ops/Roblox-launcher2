# RBX Launcher 2.0

Панель поверх Roblox (Android): открывается правым Shift, показывает пинг, ОЗУ, температуру,
умеет освобождать ОЗУ и затемнять экран. Ведёт журнал игровых сессий.

Сборка: GitHub Actions (`gradle assembleDebug`) -> артефакт `rbx-launcher-apk` -> `app-debug.apk`.

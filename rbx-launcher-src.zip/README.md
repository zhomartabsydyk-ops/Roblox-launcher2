# RBX Launcher 3.0

Панель, моды и эффекты поверх Roblox (Android). Горячая клавиша настраивается (по умолчанию Right Shift).
Developers: smoshok & Claude.

Сборка: GitHub Actions (`gradle assembleDebug`) -> артефакт `rbx-launcher-apk` -> `app-debug.apk`.

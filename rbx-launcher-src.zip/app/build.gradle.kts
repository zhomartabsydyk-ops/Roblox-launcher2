plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rbx.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rbx.launcher"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "3.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

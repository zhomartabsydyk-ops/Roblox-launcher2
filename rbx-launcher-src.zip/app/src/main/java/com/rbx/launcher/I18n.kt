package com.rbx.launcher

import android.content.Context

object I18n {
    private var lang = "ru"

    fun init(c: Context) {
        lang = Cfg.lang(c)
    }

    fun set(c: Context, l: String) {
        Cfg.putStr(c, "lang", l)
        lang = l
    }

    fun current() = lang

    fun t(k: String): String = (if (lang == "en") en else ru)[k] ?: ru[k] ?: k

    private val ru = mapOf(
        "nav_home" to "Главная", "nav_mods" to "Моды", "nav_fx" to "Эффекты",
        "nav_settings" to "Настройки", "nav_sessions" to "Сессии",
        "hello" to "Привет, %s!", "hello_sub" to "Всё готово к игре.",
        "launch" to "ЗАПУСТИТЬ ROBLOX", "not_installed" to "Roblox не установлен",
        "files_access" to "Доступ к файлам (журнал сессий)",
        "hotkey_svc" to "Горячая клавиша и панель в игре",
        "grant" to "Выдать", "enable" to "Включить",
        "a11y_toast" to "Найди «RBX Launcher» и включи",
        "hint_use" to "Нажми %s в игре - откроется панель. Моды и эффекты настраиваются во вкладках слева.",
        "toggle_panel" to "Показать / скрыть панель",
        "need_service" to "Сначала включи службу на главной",
        "mods_title" to "Моды", "mods_sub" to "Включай, двигай и настраивай как хочешь",
        "mod_keys" to "Keystrokes", "mod_keys_d" to "Показывает нажатые W A S D, Shift и пробел",
        "mod_ping" to "Пинг", "mod_ping_d" to "Задержка до серверов Roblox",
        "mod_ram" to "ОЗУ", "mod_ram_d" to "Свободная память",
        "mod_battery" to "Батарея", "mod_battery_d" to "Заряд и температура",
        "mod_session" to "Таймер сессии", "mod_session_d" to "Сколько ты уже в игре",
        "mod_clock" to "Часы", "mod_clock_d" to "Текущее время",
        "position" to "Позиция", "x_off" to "Отступ по X", "y_off" to "Отступ по Y",
        "size" to "Размер", "opacity" to "Непрозрачность", "color" to "Цвет",
        "fx_title" to "Эффекты экрана", "fx_sub" to "Фильтры поверх игры",
        "fx_dim" to "Затемнение", "fx_vig" to "Виньетка", "fx_tint" to "Оттенок",
        "tint_off" to "Выкл", "tint_warm" to "Тёплый", "tint_cool" to "Холодный",
        "fx_amt" to "Сила оттенка",
        "set_title" to "Настройки", "set_lang" to "Язык", "set_accent" to "Цвет интерфейса",
        "set_amoled" to "Чёрный фон (AMOLED)", "set_hotkey" to "Горячая клавиша панели",
        "change" to "Изменить", "reset_key" to "Сбросить", "cancel" to "Отмена",
        "press_key" to "Нажми нужную клавишу…",
        "set_panel" to "Панель в игре", "panel_scale" to "Размер панели",
        "panel_opacity" to "Непрозрачность панели",
        "reset_all" to "Сбросить все настройки", "logout" to "Выйти из аккаунта",
        "sess_title" to "Игровые сессии",
        "sess_empty" to "Пока пусто. Поиграй в Roblox больше минуты.",
        "sess_row" to "%s • %s мин • пинг %s мс • %s°C • ОЗУ мин %s МБ",
        "ms" to "мс", "mb" to "МБ",
        "boost" to "🚀 Освободить ОЗУ",
        "boost_done" to "Закрыто фоновых приложений: %d. ОЗУ: %s МБ",
        "dim_btn" to "🌙 Затемнение: %s", "close_btn" to "Закрыть (%s)", "mods_hdr" to "Моды",
        "info_ram" to "ОЗУ свободно: %d / %d МБ",
        "info_batt" to "Батарея: %d%%  •  %s°C",
        "info_therm" to "Нагрев: %s", "info_ping" to "Пинг до Roblox: %s",
        "info_screen" to "Экран: %d Гц", "info_session" to "Сессия: %s",
        "not_running" to "Roblox не запущен",
        "th0" to "норма", "th1" to "лёгкий", "th2" to "умеренный",
        "th3" to "сильный", "th4" to "критичный", "th5" to "аварийный",
        "hud_ping" to "Пинг", "hud_ram" to "ОЗУ", "off" to "выкл",
        "loading" to "Загрузка…", "splash_img" to "Картинка загрузки", "choose" to "Выбрать",
        "saved" to "Сохранено",
        "nav_cursor" to "Курсор", "cur_title" to "Курсор", "cur_sub" to "Свой указатель по центру экрана",
        "cur_on" to "Показывать курсор", "cur_shape" to "Вид", "cur_thick" to "Толщина", "cur_gap" to "Зазор в центре",
        "cur_outline" to "Чёрная обводка",
        "cur_note" to "Курсор стоит по центру экрана и помогает там, где Roblox прячет указатель (блокировка мыши, вид от первого лица). За двигающейся мышью он не следует: если лаунчер начнёт перехватывать мышь, Android перестанет отдавать её игре.",
        "svc_dead" to "Служба выключилась (система её закрыла). Выключи и снова включи её",
        "battery_row" to "Не закрывать в фоне (батарея)", "autostart" to "Автозапуск (Xiaomi)",
        "whats_new" to "Что нового",
        "whats_text" to "• Курсор: 8 видов, размер, цвет, обводка\n• Плавные анимации интерфейса\n• Защита службы от закрытия системой (HyperOS)\n• Моды и эффекты настраиваются во вкладках", "lang_ru" to "Русский", "lang_en" to "English"
    )

    private val en = mapOf(
        "nav_home" to "Home", "nav_mods" to "Mods", "nav_fx" to "Effects",
        "nav_settings" to "Settings", "nav_sessions" to "Sessions",
        "hello" to "Hi, %s!", "hello_sub" to "Ready to play.",
        "launch" to "LAUNCH ROBLOX", "not_installed" to "Roblox is not installed",
        "files_access" to "File access (session log)",
        "hotkey_svc" to "In-game hotkey & panel",
        "grant" to "Grant", "enable" to "Enable",
        "a11y_toast" to "Find \"RBX Launcher\" and turn it on",
        "hint_use" to "Press %s in game to open the panel. Mods and effects are configured in the tabs on the left.",
        "toggle_panel" to "Show / hide panel",
        "need_service" to "Enable the service on Home first",
        "mods_title" to "Mods", "mods_sub" to "Toggle, move and tweak to your liking",
        "mod_keys" to "Keystrokes", "mod_keys_d" to "Shows pressed W A S D, Shift and Space",
        "mod_ping" to "Ping", "mod_ping_d" to "Latency to Roblox servers",
        "mod_ram" to "Memory", "mod_ram_d" to "Free memory",
        "mod_battery" to "Battery", "mod_battery_d" to "Charge and temperature",
        "mod_session" to "Session timer", "mod_session_d" to "Time spent in game",
        "mod_clock" to "Clock", "mod_clock_d" to "Current time",
        "position" to "Position", "x_off" to "X offset", "y_off" to "Y offset",
        "size" to "Size", "opacity" to "Opacity", "color" to "Color",
        "fx_title" to "Screen effects", "fx_sub" to "Filters on top of the game",
        "fx_dim" to "Dim", "fx_vig" to "Vignette", "fx_tint" to "Tint",
        "tint_off" to "Off", "tint_warm" to "Warm", "tint_cool" to "Cool",
        "fx_amt" to "Tint strength",
        "set_title" to "Settings", "set_lang" to "Language", "set_accent" to "Accent color",
        "set_amoled" to "Pure black (AMOLED)", "set_hotkey" to "Panel hotkey",
        "change" to "Change", "reset_key" to "Reset", "cancel" to "Cancel",
        "press_key" to "Press the key you want…",
        "set_panel" to "In-game panel", "panel_scale" to "Panel size",
        "panel_opacity" to "Panel opacity",
        "reset_all" to "Reset all settings", "logout" to "Log out",
        "sess_title" to "Game sessions",
        "sess_empty" to "Nothing yet. Play Roblox for over a minute.",
        "sess_row" to "%s • %s min • ping %s ms • %s°C • min RAM %s MB",
        "ms" to "ms", "mb" to "MB",
        "boost" to "🚀 Free up RAM",
        "boost_done" to "Closed background apps: %d. RAM: %s MB",
        "dim_btn" to "🌙 Dim: %s", "close_btn" to "Close (%s)", "mods_hdr" to "Mods",
        "info_ram" to "RAM free: %d / %d MB",
        "info_batt" to "Battery: %d%%  •  %s°C",
        "info_therm" to "Heat: %s", "info_ping" to "Ping to Roblox: %s",
        "info_screen" to "Display: %d Hz", "info_session" to "Session: %s",
        "not_running" to "Roblox not running",
        "th0" to "normal", "th1" to "light", "th2" to "moderate",
        "th3" to "severe", "th4" to "critical", "th5" to "emergency",
        "hud_ping" to "Ping", "hud_ram" to "RAM", "off" to "off",
        "loading" to "Loading…", "splash_img" to "Loading image", "choose" to "Choose",
        "saved" to "Saved",
        "nav_cursor" to "Cursor", "cur_title" to "Cursor", "cur_sub" to "Your own pointer at screen centre",
        "cur_on" to "Show cursor", "cur_shape" to "Style", "cur_thick" to "Thickness", "cur_gap" to "Centre gap",
        "cur_outline" to "Black outline",
        "cur_note" to "The cursor sits at the screen centre and helps where Roblox hides the pointer (mouse lock, first person). It does not follow a moving mouse: if the launcher grabbed the mouse, Android would stop passing it to the game.",
        "svc_dead" to "The service stopped (the system closed it). Turn it off and on again",
        "battery_row" to "Keep alive in background (battery)", "autostart" to "Autostart (Xiaomi)",
        "whats_new" to "What's new",
        "whats_text" to "• Cursor: 8 styles, size, colour, outline\n• Smooth UI animations\n• Service protected from being closed by the system (HyperOS)\n• Mods and effects are set up in the tabs", "lang_ru" to "Русский", "lang_en" to "English"
    )
}

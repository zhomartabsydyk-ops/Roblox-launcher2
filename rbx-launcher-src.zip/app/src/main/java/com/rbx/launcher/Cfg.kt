package com.rbx.launcher

import android.content.Context
import android.content.SharedPreferences
import android.view.KeyEvent
import java.util.Locale

/** Все пользовательские настройки (файл "cfg"). */
object Cfg {
    const val FILE = "cfg"
    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getInt(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun getBool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun getStr(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun reset(c: Context) = sp(c).edit().clear().apply()

    fun lang(c: Context): String =
        sp(c).getString("lang", null) ?: if (Locale.getDefault().language == "ru") "ru" else "en"

    fun hotkey(c: Context): Int = getInt(c, "hotkey", KeyEvent.KEYCODE_SHIFT_RIGHT)
    fun accent(c: Context): Int = getInt(c, "accent", 0xFF35B8F0.toInt())
    fun amoled(c: Context): Boolean = getBool(c, "amoled", false)

    fun keyName(code: Int): String = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
        .replace("SHIFT_RIGHT", "Right Shift").replace("SHIFT_LEFT", "Left Shift")
        .replace("CTRL_RIGHT", "Right Ctrl").replace("ALT_RIGHT", "Right Alt")
}

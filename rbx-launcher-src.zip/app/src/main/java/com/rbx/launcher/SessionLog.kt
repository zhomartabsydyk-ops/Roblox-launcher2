package com.rbx.launcher

import android.content.Context
import android.os.Environment
import java.io.File

/** Журнал игровых сессий: Documents/RBXLauncher/sessions.csv (запасной путь - папка приложения). */
object SessionLog {
    private const val HEADER = "date,minutes,avg_ping_ms,max_ping_ms,max_temp_c,min_free_ram_mb"

    private fun dirs(c: Context): List<File> = listOf(
        File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "RBXLauncher"),
        File(c.getExternalFilesDir(null) ?: c.filesDir, "sessions")
    )

    fun append(c: Context, line: String) {
        for (d in dirs(c)) {
            try {
                d.mkdirs()
                val f = File(d, "sessions.csv")
                val isNew = !f.exists()
                f.appendText((if (isNew) HEADER + "\n" else "") + line + "\n")
                return
            } catch (e: Exception) {
                // пробуем следующий путь
            }
        }
    }

    fun last(c: Context, n: Int): List<String> {
        for (d in dirs(c)) {
            try {
                val f = File(d, "sessions.csv")
                if (f.exists()) return f.readLines().drop(1).takeLast(n).reversed()
            } catch (e: Exception) {
                // пробуем следующий путь
            }
        }
        return emptyList()
    }
}

package com.rbx.launcher

import android.content.Context
import android.webkit.CookieManager

/**
 * Вход делается на официальной странице roblox.com внутри WebView.
 * Пароль и cookie приложение НЕ читает, НЕ хранит и НЕ отправляет:
 * проверяется только факт наличия сессии (есть ли cookie с таким именем).
 */
object Auth {
    private fun sp(c: Context) = c.getSharedPreferences("rbx", Context.MODE_PRIVATE)

    fun hasSession(): Boolean =
        CookieManager.getInstance().getCookie("https://www.roblox.com")
            ?.contains(".ROBLOSECURITY") == true

    fun username(c: Context): String = sp(c).getString("user", null) ?: "Roblox"

    fun setUsername(c: Context, name: String) {
        sp(c).edit().putString("user", name).apply()
    }

    fun logout(c: Context) {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        sp(c).edit().clear().apply()
    }
}

package com.rbx.launcher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import java.io.File

object Ui {
    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun round(c: Context, color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(c, r).toFloat()
        }

    fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

    fun tv(c: Context, text: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(c).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(c, 3), 0, dp(c, 3))
        }

    fun btn(c: Context, text: String, bg: Int, onClick: () -> Unit): Button =
        Button(c).apply {
            this.text = text
            isAllCaps = false
            minWidth = 0
            minHeight = 0
            setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10))
            setTextColor(Color.WHITE)
            background = round(c, bg, 12)
            setOnClickListener { onClick() }
            setOnTouchListener { v, e ->
                when (e.action) {
                    android.view.MotionEvent.ACTION_DOWN ->
                        v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                }
                false
            }
        }

    fun tonal(c: Context, text: String, accent: Int, onClick: () -> Unit): Button =
        btn(c, text, withAlpha(accent, 0x38), onClick).apply { setTextColor(accent) }

    fun edit(c: Context, hint: String, bg: Int): EditText = EditText(c).apply {
        this.hint = hint
        setHintTextColor(0xFF6E7381.toInt())
        setTextColor(Color.WHITE)
        textSize = 14f
        isSingleLine = true
        background = round(c, bg, 12)
        setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
    }

    fun styleSwitch(s: Switch, accent: Int) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(states, intArrayOf(accent, 0xFFB5BAC6.toInt()))
        s.trackTintList = ColorStateList(states, intArrayOf(withAlpha(accent, 0x66), 0xFF3A3D47.toInt()))
    }

    fun pressFx(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    /** Картинка загрузки, выбранная пользователем (или null - тогда стандартная). */
    fun splash(c: Context): Bitmap? {
        val f = File(c.filesDir, "splash.img")
        if (!f.exists()) return null
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (o.outWidth / s > 1024 || o.outHeight / s > 1024) s *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        } catch (e: Exception) {
            null
        }
    }
}

package com.rbx.launcher

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener

class LoginActivity : Activity() {
    private lateinit var web: WebView
    private var done = false

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                CookieManager.getInstance().flush()
                val host = Uri.parse(url).host ?: ""
                val onLoginPage = url.contains("login", ignoreCase = true)
                if (!done && Auth.cookie() && !onLoginPage && host.endsWith("roblox.com")) {
                    done = true
                    fetchNameAndFinish(view)
                }
            }
        }
        web.loadUrl("https://www.roblox.com/login")
    }

    /** Имя пользователя берём официальным API Roblox изнутри страницы (cookie мы не трогаем). */
    private fun fetchNameAndFinish(view: WebView) {
        val js = "(function(){try{var x=new XMLHttpRequest();" +
            "x.open('GET','https://users.roblox.com/v1/users/authenticated',false);" +
            "x.withCredentials=true;x.send();return x.responseText;}catch(e){return '';}})()"
        view.evaluateJavascript(js) { value ->
            var name = "Roblox"
            try {
                val s = JSONTokener(value).nextValue() as? String
                if (!s.isNullOrEmpty()) {
                    val n = JSONObject(s).optString("name")
                    if (n.isNotEmpty()) name = n
                }
            } catch (e: Exception) {
                // оставляем имя по умолчанию
            }
            Auth.setUsername(this, name)
            setResult(RESULT_OK)
            finish()
        }
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) {
            web.goBack()
        } else {
            setResult(RESULT_CANCELED)
            finish()
        }
    }
}

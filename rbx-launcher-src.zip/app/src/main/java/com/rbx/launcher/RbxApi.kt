package com.rbx.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.Executors

class GameInfo(
    val placeId: String,
    val universeId: String,
    val name: String,
    val playing: Long,
    val votePct: Int,
    var iconUrl: String?
)

class ServerInfo(val id: String, val playing: Int, val max: Int, val ping: Int, val fps: Int)
class PrivServer(val name: String, val code: String)

/**
 * Публичные веб-API Roblox (без входа): топ игр, иконки, список публичных серверов.
 * Приватные серверы запрашиваются изнутри WebView с твоей сессией - cookie приложение не видит.
 */
object RbxApi {
    private val pool = Executors.newFixedThreadPool(4)
    private val ui = Handler(Looper.getMainLooper())
    private val cache = LruCache<String, Bitmap>(60)

    private fun get(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) RBXLauncher/3.3")
        c.setRequestProperty("Accept", "application/json")
        if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
    } catch (e: Exception) {
        null
    }

    private fun <T> bg(work: () -> T, done: (T) -> Unit) {
        pool.execute {
            val r = work()
            ui.post { done(r) }
        }
    }

    // ---------- топ игр ----------
    fun topGames(done: (List<GameInfo>) -> Unit) = bg({
        var list = fromExplore()
        if (list.isEmpty()) list = fromFallback()
        fillIcons(list)
        list
    }, done)

    private fun fromExplore(): List<GameInfo> {
        val out = ArrayList<GameInfo>()
        val sid = UUID.randomUUID().toString()
        val body = get(
            "https://apis.roblox.com/explore-api/v1/get-sort-content?sessionId=$sid&device=computer&country=all&sortId=top-playing-now"
        ) ?: return out
        try {
            val arr = JSONObject(body).optJSONArray("games") ?: return out
            for (i in 0 until minOf(arr.length(), 24)) {
                val g = arr.getJSONObject(i)
                val up = g.optLong("totalUpVotes", 0)
                val down = g.optLong("totalDownVotes", 0)
                val pct = if (up + down > 0) (up * 100 / (up + down)).toInt() else 0
                out.add(
                    GameInfo(
                        g.optString("rootPlaceId"), g.optString("universeId"), g.optString("name", "Game"),
                        g.optLong("playerCount", g.optLong("playing", 0)), pct, null
                    )
                )
            }
        } catch (e: Exception) {
            return ArrayList()
        }
        return out.filter { it.placeId.isNotEmpty() && it.placeId != "0" }
    }

    /** Запасной список известных игр, если «топ» не загрузился. */
    private fun fromFallback(): List<GameInfo> {
        val places = listOf(
            "920587237", "2753915549", "142823291", "4924922222", "1537690962",
            "1962086868", "16732694052", "6516141723", "606849621", "189707"
        )
        val uni = ArrayList<String>()
        for (p in places) {
            val b = get("https://apis.roblox.com/universes/v1/places/$p/universe") ?: continue
            try {
                val u = JSONObject(b).optLong("universeId", 0)
                if (u > 0) uni.add(u.toString())
            } catch (e: Exception) {
                // пропускаем
            }
        }
        if (uni.isEmpty()) return emptyList()
        val ids = uni.joinToString(",")
        val det = get("https://games.roblox.com/v1/games?universeIds=$ids") ?: return emptyList()
        val votes = HashMap<Long, Int>()
        get("https://games.roblox.com/v1/games/votes?universeIds=$ids")?.let { vb ->
            try {
                val a = JSONObject(vb).optJSONArray("data")
                if (a != null) {
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        val up = o.optLong("upVotes", 0)
                        val down = o.optLong("downVotes", 0)
                        votes[o.optLong("id")] = if (up + down > 0) (up * 100 / (up + down)).toInt() else 0
                    }
                }
            } catch (e: Exception) {
                // без оценок
            }
        }
        val out = ArrayList<GameInfo>()
        try {
            val a = JSONObject(det).optJSONArray("data") ?: return emptyList()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val id = o.optLong("id")
                out.add(
                    GameInfo(
                        o.optString("rootPlaceId"), id.toString(), o.optString("name", "Game"),
                        o.optLong("playing", 0), votes[id] ?: 0, null
                    )
                )
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return out.sortedByDescending { it.playing }
    }

    private fun fillIcons(list: List<GameInfo>) {
        val ids = list.map { it.universeId }.filter { it.isNotEmpty() && it != "0" }.distinct()
        if (ids.isEmpty()) return
        val body = get(
            "https://thumbnails.roblox.com/v1/games/icons?universeIds=${ids.joinToString(",")}" +
                "&returnPolicy=PlaceHolder&size=256x256&format=Png&isCircular=false"
        ) ?: return
        try {
            val a = JSONObject(body).optJSONArray("data") ?: return
            val map = HashMap<String, String>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val u = o.optString("imageUrl")
                if (u.isNotEmpty()) map[o.optLong("targetId").toString()] = u
            }
            for (g in list) g.iconUrl = map[g.universeId]
        } catch (e: Exception) {
            // без иконок
        }
    }

    // ---------- серверы ----------
    fun servers(placeId: String, done: (List<ServerInfo>?) -> Unit) = bg({
        val body = get("https://games.roblox.com/v1/games/$placeId/servers/Public?sortOrder=Asc&excludeFullGames=false&limit=100")
        if (body == null) {
            null
        } else {
            try {
                val a = JSONObject(body).optJSONArray("data")
                val out = ArrayList<ServerInfo>()
                if (a != null) {
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        out.add(
                            ServerInfo(
                                o.optString("id"), o.optInt("playing"), o.optInt("maxPlayers"),
                                o.optInt("ping"), o.optDouble("fps", 0.0).toInt()
                            )
                        )
                    }
                }
                out as List<ServerInfo>?
            } catch (e: Exception) {
                null
            }
        }
    }, done)

    /** Приватные серверы: запрос идёт из страницы roblox.com внутри WebView (с твоей сессией). */
    fun privateServers(ctx: Context, placeId: String, done: (List<PrivServer>?) -> Unit) {
        val wv = WebView(ctx)
        wv.settings.javaScriptEnabled = true
        var finished = false
        fun finish(r: List<PrivServer>?) {
            if (finished) return
            finished = true
            try {
                wv.stopLoading()
                wv.destroy()
            } catch (e: Exception) {
                // уже закрыт
            }
            done(r)
        }
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (finished || !url.contains("roblox.com")) return
                val js = "(function(){try{var x=new XMLHttpRequest();" +
                    "x.open('GET','https://games.roblox.com/v1/games/$placeId/private-servers?limit=25&excludeFriendServers=false',false);" +
                    "x.withCredentials=true;x.send();return x.status+'|'+x.responseText;}catch(e){return '0|';}})()"
                view.evaluateJavascript(js) { value ->
                    var result: List<PrivServer>? = null
                    try {
                        val s = JSONTokener(value).nextValue() as? String
                        if (s != null && s.startsWith("200|")) {
                            val a = JSONObject(s.substring(4)).optJSONArray("data")
                            val out = ArrayList<PrivServer>()
                            if (a != null) {
                                for (i in 0 until a.length()) {
                                    val o = a.getJSONObject(i)
                                    out.add(PrivServer(o.optString("name", "Private server"), o.optString("accessCode")))
                                }
                            }
                            result = out
                        }
                    } catch (e: Exception) {
                        result = null
                    }
                    finish(result)
                }
            }
        }
        wv.loadUrl("https://www.roblox.com/")
        ui.postDelayed({ finish(null) }, 15000)
    }

    // ---------- картинки ----------
    fun loadImage(url: String?, iv: ImageView) {
        if (url == null) return
        iv.tag = url
        val c = cache.get(url)
        if (c != null) {
            iv.setImageBitmap(c)
            return
        }
        pool.execute {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val bm = BitmapFactory.decodeStream(conn.inputStream)
                if (bm != null) {
                    cache.put(url, bm)
                    ui.post { if (iv.tag == url) iv.setImageBitmap(bm) }
                }
            } catch (e: Exception) {
                // без картинки
            }
        }
    }
}

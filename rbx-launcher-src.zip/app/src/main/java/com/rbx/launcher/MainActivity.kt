package com.rbx.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Game(val id: String, var name: String, var fav: Boolean, var last: Long)

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var panelView: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var sidebar: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var footer: TextView
    private var tab = 0
    private val hist = ArrayList<Int>()
    private var hpos = 0
    private var openMod: String? = null
    private var askedStorage = false
    private var loginOpen = false
    private var animateNext = true
    private var gameQuery = ""

    private val white = Color.WHITE
    private val sub = 0xFF9096A3.toInt()
    private val green = 0xFF4ADE80.toInt()
    private val soft = 0xFF30323C.toInt()
    private val accents = intArrayOf(
        0xFF35B8F0.toInt(), 0xFF8B5CF6.toInt(), 0xFF22C55E.toInt(),
        0xFFEF4444.toInt(), 0xFFF59E0B.toInt(), 0xFFEC4899.toInt()
    )
    private val modColors = intArrayOf(0xFFFFFFFF.toInt()) + accents
    private val tabKeys = listOf("nav_home", "nav_games", "nav_mods", "nav_cursor", "nav_fx", "nav_sessions", "nav_settings")
    private val tabIcons = intArrayOf(
        IconView.ROCKET, IconView.GAMEPAD, IconView.GRID, IconView.CROSSHAIR,
        IconView.SPARKLE, IconView.CLOCK, IconView.SLIDERS
    )

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun t(k: String) = I18n.t(k)
    private fun accent() = Cfg.accent(this)
    private fun amo() = Cfg.amoled(this)
    private fun panelc() = if (amo()) 0xFF000000.toInt() else 0xFF191B21.toInt()
    private fun cardc() = if (amo()) 0xFF0F0F11.toInt() else 0xFF23252D.toInt()
    private fun sidec() = if (amo()) 0xFF050506.toInt() else 0xFF14151A.toInt()
    private fun tv(s: String, sp: Float, c: Int, b: Boolean = false): TextView = Ui.tv(this, s, sp, c, b)
    private fun btn(s: String, bg: Int, f: () -> Unit) =
        if (bg == accent()) Ui.tonal(this, s, bg, f) else Ui.btn(this, s, bg, f)
    private fun sw(): Switch = Switch(this).also { Ui.styleSwitch(it, accent()) }
    private fun lp(top: Int, hDp: Int = 0): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        if (hDp == 0) ViewGroup.LayoutParams.WRAP_CONTENT else dp(hDp)
    ).apply { topMargin = dp(top) }

    private fun add(v: View, p: ViewGroup.LayoutParams? = null) {
        if (p != null) content.addView(v, p) else content.addView(v)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun refreshOverlay() { KeyService.instance?.refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        I18n.init(this)
        hist.add(0)
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        root = FrameLayout(this)
        root.addView(StarsView(this))

        panelView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
        }
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
        }
        panelView.addView(topBar, LinearLayout.LayoutParams(mp, dp(54)))

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sidebar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(8), 0, dp(14))
        }
        body.addView(sidebar, LinearLayout.LayoutParams(dp(78), mp))
        scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(24))
        }
        scroll.addView(content)
        body.addView(scroll, LinearLayout.LayoutParams(0, mp, 1f))
        panelView.addView(body, LinearLayout.LayoutParams(mp, 0, 1f))

        footer = tv("Developers: smoshok & Claude", 11f, sub).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        }
        panelView.addView(footer, LinearLayout.LayoutParams(mp, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(panelView, FrameLayout.LayoutParams(mp, mp).apply { setMargins(dp(12), dp(12), dp(12), dp(12)) })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        check()
    }

    /** 1) обязательный вход в Roblox  2) запрос доступа к файлам  3) отрисовка */
    private fun check() {
        if (!Auth.hasSession(this)) {
            if (!loginOpen) {
                loginOpen = true
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(this, LoginActivity::class.java), 10)
            }
            return
        }
        if (!askedStorage && !hasStorage()) {
            askedStorage = true
            requestStorage()
        }
        renderAll()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10) {
            loginOpen = false
            if (resultCode != RESULT_OK && !Auth.hasSession(this)) finish()
        } else if (requestCode == 20 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { inp ->
                    File(filesDir, "splash.img").outputStream().use { out -> inp.copyTo(out) }
                }
                toast(t("saved"))
            } catch (e: Exception) {
                toast("Error")
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        @Suppress("DEPRECATION")
        super.onRequestPermissionsResult(code, perms, res)
        renderAll()
    }

    // ---------- файлы / служба ----------
    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 11)
        }
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.split(':').any { it.contains(packageName) && it.contains("KeyService") }
    }

    private fun launchRoblox() {
        val i = packageManager.getLaunchIntentForPackage(KeyService.ROBLOX)
        if (i != null) {
            startActivity(i)
        } else {
            toast(t("not_installed"))
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${KeyService.ROBLOX}")))
            } catch (e: Exception) {
                // нет магазина
            }
        }
    }

    private fun ignoringBattery(): Boolean =
        (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun requestBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                // нет такого экрана
            }
        }
    }

    private fun openAutostart() {
        try {
            startActivity(
                Intent().setComponent(
                    ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
                )
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    // ---------- каркас в стиле Lunar ----------
    private fun go(i: Int, push: Boolean = true) {
        if (push) {
            while (hist.size > hpos + 1) hist.removeAt(hist.size - 1)
            hist.add(i)
            hpos = hist.size - 1
        }
        tab = i
        renderTop()
        renderNav()
        renderTab(true)
    }

    private fun renderAll() {
        panelView.background = Ui.round(this, panelc(), 20)
        footer.setBackgroundColor(sidec())
        renderTop()
        renderNav()
        renderTab(animateNext)
        animateNext = false
    }

    private fun renderTop() {
        topBar.removeAllViews()
        topBar.setBackgroundColor(sidec())
        topBar.addView(IconView(this, IconView.ROCKET, accent()), LinearLayout.LayoutParams(dp(24), dp(24)))
        topBar.addView(tv("RBX Launcher ▾", 15f, white, true).apply { setPadding(dp(8), 0, dp(18), 0) })
        topBar.addView(tv("←", 20f, if (hpos > 0) white else sub).apply {
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { if (hpos > 0) { hpos--; go(hist[hpos], false) } }
        })
        topBar.addView(tv("→", 20f, if (hpos < hist.size - 1) white else sub).apply {
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { if (hpos < hist.size - 1) { hpos++; go(hist[hpos], false) } }
        })
        val d0 = detail
        val crumbText = if (tab == 1 && d0 != null) t("nav_games") + "  ›  " + d0.name else t(tabKeys[tab])
        topBar.addView(tv(crumbText, 14f, sub).apply { setPadding(dp(14), 0, 0, 0) })
        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        val name = Auth.username(this)
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(5), dp(14), dp(5))
            background = Ui.round(this@MainActivity, soft, 18)
        }
        val av = tv(name.take(1).uppercase(), 12f, white, true).apply {
            gravity = Gravity.CENTER
            background = Ui.round(this@MainActivity, accent(), 12)
        }
        chip.addView(av, LinearLayout.LayoutParams(dp(24), dp(24)))
        chip.addView(tv(name, 13f, white).apply { setPadding(dp(8), 0, 0, 0) })
        topBar.addView(chip)
    }

    private fun renderNav() {
        sidebar.removeAllViews()
        sidebar.setBackgroundColor(sidec())
        for (i in tabKeys.indices) {
            val sel = i == tab
            val tile = FrameLayout(this)
            if (sel) tile.background = Ui.round(this, 0xFF3B3E49.toInt(), 14)
            tile.setOnClickListener {
                if (i != tab) {
                    go(i)
                } else if (i == 1 && detail != null) {
                    detail = null
                    renderTop()
                    renderTab(true)
                }
            }
            tile.setOnLongClickListener { toast(t(tabKeys[i])); true }
            Ui.pressFx(tile)
            tile.addView(
                IconView(this, tabIcons[i], if (sel) white else 0xFFA0A5B1.toInt()),
                FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER)
            )
            sidebar.addView(tile, LinearLayout.LayoutParams(dp(54), dp(54)).apply { topMargin = dp(10) })
        }
    }

    private fun renderTab(animate: Boolean = false) {
        val keep = scroll.scrollY
        content.removeAllViews()
        when (tab) {
            0 -> home()
            1 -> gamesTab()
            2 -> mods()
            3 -> cursorTab()
            4 -> fx()
            5 -> sessions()
            else -> settings()
        }
        if (animate) {
            scroll.scrollTo(0, 0)
            for (i in 0 until content.childCount) {
                val v = content.getChildAt(i)
                v.alpha = 0f
                v.translationY = dp(18).toFloat()
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(i * 35L).setDuration(260)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
        } else {
            scroll.post { scroll.scrollTo(0, keep) }
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = Ui.round(this@MainActivity, cardc(), 16)
    }

    private fun row(title: String, ok: Boolean, btnText: String, action: () -> Unit) {
        val c = card()
        c.addView(tv(title + if (ok) "  ✅" else "  ❌", 15f, white))
        if (!ok) c.addView(btn(btnText, accent()) { action() }, lp(8))
        add(c, lp(10))
    }

    // ---------- Панель запуска (главная) ----------
    private fun home() {
        add(tv(String.format(t("welcome_back"), Auth.username(this)), 20f, white, true))

        val wide = resources.configuration.screenWidthDp >= 600
        val hero = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF0E1322.toInt(), 0xFF1A2B4C.toInt())
            ).apply { cornerRadius = dp(22).toFloat() }
        }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            val bm = Ui.splash(this@MainActivity)
            if (bm != null) setImageBitmap(bm) else setImageResource(R.drawable.splash_default)
        }
        val imgW = if (wide) 170 else 90
        hero.addView(
            img,
            FrameLayout.LayoutParams(dp(imgW), dp(imgW), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(20) }
        )
        val txt = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(18), dp(imgW + 30), dp(18))
        }
        txt.addView(tv(t("hero_title") + " 🚀", if (wide) 24f else 18f, white, true))
        txt.addView(tv(t("hello_sub"), 14f, sub))
        txt.addView(Ui.tonal(this, "▶  " + t("launch"), accent()) { launchRoblox() }, lp(14))
        hero.addView(txt, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        add(hero, lp(12, if (wide) 210 else 230))

        val recent = loadGames().sortedByDescending { it.last }.take(3)
        if (recent.isNotEmpty()) {
            add(tv(t("recent_games"), 18f, white, true), lp(22))
            for (g in recent) add(gameRow(g, false), lp(8))
        }

        add(tv(t("status"), 18f, white, true), lp(22))
        row(t("files_access"), hasStorage(), t("grant")) { requestStorage() }
        val svcOn = a11yOn()
        val alive = KeyService.instance != null
        val openA11y = {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast(t("a11y_toast"))
        }
        if (svcOn && !alive) row(t("svc_dead"), false, t("enable")) { openA11y() }
        else row(t("hotkey_svc"), svcOn, t("enable")) { openA11y() }
        row(t("battery_row"), ignoringBattery(), t("grant")) { requestBattery() }
        val mf = Build.MANUFACTURER.lowercase()
        if (mf.contains("xiaomi") || mf.contains("redmi") || mf.contains("poco")) {
            add(btn(t("autostart"), soft) { openAutostart() }, lp(10))
        }
        add(tv(String.format(t("hint_use"), Cfg.keyName(Cfg.hotkey(this))), 14f, sub), lp(14))
        add(btn(t("toggle_panel"), soft) {
            val s = KeyService.instance
            if (s != null) s.togglePanel() else toast(t("need_service"))
        }, lp(12))
        val wn = card()
        wn.addView(tv(t("whats_new"), 15f, white, true))
        wn.addView(tv(t("whats_text"), 13f, sub))
        add(wn, lp(16))
    }

    // ---------- Games ----------
    private var detail: GameInfo? = null
    private var gMode = 0
    private var topCache: List<GameInfo>? = null
    private var topLoading = false
    private var srvSort = 0
    private var hideFull = true
    private var srvTab = 0
    private var pubList: List<ServerInfo>? = null
    private var pubLoading = false
    private var pubFailed = false
    private var privList: List<PrivServer>? = null
    private var privLoading = false
    private var privFailed = false

    private fun loadGames(): MutableList<Game> {
        val out = ArrayList<Game>()
        try {
            val a = JSONArray(Cfg.getStr(this, "games", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Game(o.getString("id"), o.optString("name", "Game"), o.optBoolean("fav", false), o.optLong("last", 0L)))
            }
        } catch (e: Exception) {
            // пустой список
        }
        return out
    }

    private fun mutateGames(f: (MutableList<Game>) -> Unit) {
        val l = loadGames()
        f(l)
        val a = JSONArray()
        for (g in l) {
            a.put(JSONObject().put("id", g.id).put("name", g.name).put("fav", g.fav).put("last", g.last))
        }
        Cfg.putStr(this, "games", a.toString())
    }

    private fun recordPlayed(pid: String, name: String) {
        mutateGames { l ->
            val e = l.find { it.id == pid }
            if (e != null) e.last = System.currentTimeMillis()
            else l.add(Game(pid, name, false, System.currentTimeMillis()))
        }
    }

    private fun openRoblox(uri: String, pid: String, name: String) {
        recordPlayed(pid, name)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(KeyService.ROBLOX))
        } catch (e: Exception) {
            toast(t("not_installed"))
        }
    }

    private fun joinGame(g: Game) = openRoblox("roblox://experiences/start?placeId=${g.id}", g.id, g.name)

    private fun openDetail(g: GameInfo) {
        detail = g
        srvTab = 0
        pubList = null
        pubFailed = false
        privList = null
        privFailed = false
        renderTop()
        renderTab(true)
    }

    private fun fmtN(n: Long): String = when {
        n >= 1_000_000 -> String.format(java.util.Locale.US, "%.1fM", n / 1_000_000.0)
        n >= 1_000 -> String.format(java.util.Locale.US, "%.1fK", n / 1_000.0)
        else -> n.toString()
    }

    private fun gameRow(g: Game, manage: Boolean): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Ui.round(this@MainActivity, cardc(), 16)
        }
        val hue = ((g.id.hashCode() and 0x7FFFFFFF) % 360).toFloat()
        val tileColor = Color.HSVToColor(floatArrayOf(hue, 0.45f, 0.55f))
        val tile = tv(g.name.take(1).uppercase(), 18f, white, true).apply {
            gravity = Gravity.CENTER
            background = Ui.round(this@MainActivity, tileColor, 12)
        }
        r.addView(tile, LinearLayout.LayoutParams(dp(46), dp(46)))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(8), 0)
            setOnClickListener { openDetail(GameInfo(g.id, "", g.name, 0, 0, null)) }
        }
        col.addView(tv(g.name, 15f, white, true))
        col.addView(tv("ID ${g.id}", 12f, sub))
        r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (manage) {
            r.addView(tv(if (g.fav) "★" else "☆", 22f, if (g.fav) 0xFFF5C84C.toInt() else sub).apply {
                setPadding(dp(8), 0, dp(10), 0)
                setOnClickListener {
                    mutateGames { l -> l.find { it.id == g.id }?.let { x -> x.fav = !x.fav } }
                    renderTab()
                }
            })
        }
        r.addView(Ui.tonal(this, "▶  " + t("join"), accent()) { joinGame(g) })
        if (manage) {
            r.addView(tv("✕", 18f, sub).apply {
                setPadding(dp(12), 0, dp(4), 0)
                setOnClickListener {
                    mutateGames { l -> l.removeAll { it.id == g.id } }
                    renderTab()
                }
            })
        }
        return r
    }

    private fun roundedImage(h: Int): ImageView = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = Ui.round(this@MainActivity, soft, 16)
        outlineProvider = ViewOutlineProvider.BACKGROUND
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
    }

    private fun gameCard(g: GameInfo): View {
        val wide = resources.configuration.screenWidthDp >= 600
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnClickListener { openDetail(g) }
        }
        Ui.pressFx(c)
        val iv = roundedImage(if (wide) 150 else 130)
        c.addView(iv)
        RbxApi.loadImage(g.iconUrl, iv)
        c.addView(tv(g.name, 14f, white, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(2), dp(8), 0, 0)
        })
        val st = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        st.addView(tv("👥 " + fmtN(g.playing), 12f, sub).apply { setPadding(dp(2), 0, 0, 0) })
        if (g.votePct > 0) st.addView(tv("   ● ${g.votePct}%", 12f, green))
        c.addView(st)
        return c
    }

    private fun fillBrowse(box: LinearLayout) {
        box.removeAllViews()
        val q = gameQuery.trim().lowercase()
        if (gMode == 0) {
            val top = topCache
            if (top == null) {
                if (!topLoading) {
                    topLoading = true
                    RbxApi.topGames { r ->
                        topCache = r
                        topLoading = false
                        if (tab == 1 && detail == null && gMode == 0) renderTab()
                    }
                }
                box.addView(tv(t("g_loading"), 14f, sub))
                return
            }
            val list = top.filter { q.isEmpty() || it.name.lowercase().contains(q) }
            if (list.isEmpty()) {
                box.addView(tv(t("g_fail"), 14f, sub))
                box.addView(btn(t("g_refresh"), accent()) { topCache = null; renderTab() }, lp(10))
                return
            }
            val w = resources.configuration.screenWidthDp
            val perRow = if (w >= 900) 4 else if (w >= 600) 3 else 2
            var i = 0
            while (i < list.size) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (k in 0 until perRow) {
                    val idx = i + k
                    val lpc = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        .apply { setMargins(dp(5), dp(8), dp(5), dp(8)) }
                    if (idx < list.size) row.addView(gameCard(list[idx]), lpc) else row.addView(View(this), lpc)
                }
                box.addView(row)
                i += perRow
            }
            return
        }
        val list = loadGames()
            .filter { if (gMode == 1) it.last > 0 else it.fav }
            .filter { q.isEmpty() || it.name.lowercase().contains(q) || it.id.contains(q) }
            .sortedByDescending { it.last }
        if (list.isEmpty()) {
            box.addView(tv(t("games_empty"), 14f, sub))
            return
        }
        for (g in list) box.addView(gameRow(g, true), lp(8))
    }

    private fun gamesTab() {
        val d = detail
        if (d != null) {
            gameDetail(d)
            return
        }
        add(tv(t("nav_games"), 26f, white, true))
        add(tv(t("games_sub"), 14f, sub))
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, k) in listOf("g_top", "g_recent", "g_fav").withIndex()) {
            chips.addView(
                btn(t(k), if (i == gMode) accent() else soft) { gMode = i; renderTab() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { rightMargin = dp(8) }
            )
        }
        add(chips, lp(14))

        val q = Ui.edit(this, t("search_games"), cardc())
        q.setText(gameQuery)
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        q.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                gameQuery = s?.toString() ?: ""
                fillBrowse(listBox)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        add(q, lp(12))
        fillBrowse(listBox)
        add(listBox, lp(8))

        val c = card()
        c.addView(tv(t("add_by_id"), 15f, white, true))
        val link = Ui.edit(this, t("game_link_hint"), soft)
        val name = Ui.edit(this, t("game_name_hint"), soft)
        c.addView(link, lp(8))
        c.addView(name, lp(8))
        c.addView(btn(t("add"), accent()) {
            val m = Regex("\\d{4,}").find(link.text.toString())
            if (m == null) {
                toast(t("bad_link"))
            } else {
                val id = m.value
                val nm = name.text.toString().trim().ifEmpty { "Game $id" }
                mutateGames { l ->
                    l.removeAll { it.id == id }
                    l.add(Game(id, nm, true, 0L))
                }
                gMode = 2
                renderTab()
            }
        }, lp(8))
        add(c, lp(18))
    }

    // ---------- страница игры: серверы ----------
    private fun loadPublic(pid: String) {
        pubLoading = true
        RbxApi.servers(pid) { r ->
            pubLoading = false
            pubFailed = r == null
            pubList = r ?: emptyList()
            if (tab == 1 && detail?.placeId == pid && srvTab == 0) renderTab()
        }
    }

    private fun loadPrivate(pid: String) {
        privLoading = true
        RbxApi.privateServers(this, pid) { r ->
            privLoading = false
            privFailed = r == null
            privList = r ?: emptyList()
            if (tab == 1 && detail?.placeId == pid && srvTab == 1) renderTab()
        }
    }

    private fun serverRow(title: String, line: String, onJoin: () -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = Ui.round(this@MainActivity, cardc(), 16)
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(title, 15f, white, true))
        col.addView(tv(line, 12f, sub))
        r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(Ui.tonal(this, "▶  " + t("join"), accent()) { onJoin() })
        return r
    }

    private fun gameDetail(d: GameInfo) {
        add(tv("← " + t("nav_games"), 14f, accent()).apply {
            setPadding(0, dp(4), dp(16), dp(8))
            setOnClickListener {
                detail = null
                renderTop()
                renderTab(true)
            }
        })

        val head = card()
        val hr = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val iv = roundedImage(76)
        iv.layoutParams = LinearLayout.LayoutParams(dp(76), dp(76))
        hr.addView(iv)
        RbxApi.loadImage(d.iconUrl, iv)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(10), 0)
        }
        col.addView(tv(d.name, 20f, white, true))
        val stats = if (d.playing > 0) "👥 ${fmtN(d.playing)}" + (if (d.votePct > 0) "   ● ${d.votePct}%" else "") else "ID ${d.placeId}"
        col.addView(tv(stats, 13f, sub))
        hr.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        hr.addView(Ui.tonal(this, "▶  " + t("play"), accent()) {
            openRoblox("roblox://experiences/start?placeId=${d.placeId}", d.placeId, d.name)
        })
        head.addView(hr)
        add(head, lp(6))

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, k) in listOf("srv_public", "srv_private").withIndex()) {
            tabs.addView(
                btn(t(k), if (i == srvTab) accent() else soft) { srvTab = i; renderTab() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { rightMargin = dp(8) }
            )
        }
        add(tabs, lp(16))

        if (srvTab == 0) publicServers(d) else privateServers(d)
    }

    private fun publicServers(d: GameInfo) {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val sortNames = listOf("srv_best_ping", "srv_fewest", "srv_most")
        bar.addView(
            Ui.btn(this, t(sortNames[srvSort]) + " ▾", soft) { srvSort = (srvSort + 1) % 3; renderTab() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(12) }
        )
        bar.addView(android.widget.CheckBox(this).apply {
            isChecked = hideFull
            text = t("hide_full")
            setTextColor(white)
            buttonTintList = ColorStateList.valueOf(accent())
            setOnCheckedChangeListener { _, v -> hideFull = v; renderTab() }
        })
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(Ui.btn(this, t("g_refresh"), soft) { pubList = null; pubFailed = false; renderTab() })
        add(bar, lp(14))

        val l = pubList
        if (l == null) {
            if (!pubLoading) loadPublic(d.placeId)
            add(tv(t("g_loading"), 14f, sub), lp(12))
            return
        }
        if (pubFailed) {
            add(tv(t("g_fail"), 14f, sub), lp(12))
            return
        }
        var list = l.filter { !hideFull || it.playing < it.max }
        list = when (srvSort) {
            0 -> list.sortedBy { if (it.ping <= 0) Int.MAX_VALUE else it.ping }
            1 -> list.sortedBy { it.playing }
            else -> list.sortedByDescending { it.playing }
        }
        if (list.isEmpty()) {
            add(tv(t("srv_empty"), 14f, sub), lp(12))
            return
        }
        for (s in list.take(40)) {
            add(
                serverRow("Server " + s.id.take(6), "👥 ${s.playing}/${s.max}   •   ${s.ping} ms   •   ${s.fps} fps") {
                    openRoblox(
                        "roblox://experiences/start?placeId=${d.placeId}&gameInstanceId=${s.id}",
                        d.placeId, d.name
                    )
                },
                lp(8)
            )
        }
    }

    private fun privateServers(d: GameInfo) {
        val l = privList
        if (l == null) {
            if (!privLoading) loadPrivate(d.placeId)
            add(tv(t("g_loading"), 14f, sub), lp(12))
            return
        }
        add(btn(t("g_refresh"), soft) { privList = null; privFailed = false; renderTab() }, lp(14))
        if (privFailed) {
            add(tv(t("priv_fail"), 14f, sub), lp(12))
            return
        }
        if (l.isEmpty()) {
            add(tv(t("priv_empty"), 14f, sub), lp(12))
            return
        }
        for (p in l) {
            add(
                serverRow(p.name, t("srv_private")) {
                    openRoblox(
                        "roblox://experiences/start?placeId=${d.placeId}&accessCode=${p.code}",
                        d.placeId, d.name
                    )
                },
                lp(8)
            )
        }
    }

    // ---------- Моды ----------
    private fun mods() {
        add(tv(t("mods_title"), 26f, white, true))
        add(tv(t("mods_sub"), 14f, sub))
        for (m in Mods.all) modCard(m)
    }

    private fun modCard(m: ModDef) {
        val c = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv(t("mod_${m.id}"), 16f, white, true))
        texts.addView(tv(t("mod_${m.id}_d"), 12f, sub))
        head.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(sw().apply {
            isChecked = Mods.on(this@MainActivity, m)
            setOnCheckedChangeListener { _, v ->
                Mods.setOn(this@MainActivity, m, v)
                refreshOverlay()
            }
        })
        c.addView(head)
        val open = openMod == m.id
        c.addView(btn(if (open) "▲" else "⚙  " + t("change"), soft) {
            openMod = if (open) null else m.id
            renderTab()
        }, lp(8))
        if (open) modSettings(c, m)
        add(c, lp(12))
    }

    private fun modSettings(c: LinearLayout, m: ModDef) {
        val id = m.id
        c.addView(tv(t("position"), 14f, white), lp(10))
        grid(c, Mods.anchor(this, m)) { a -> Cfg.putInt(this, "m.$id.anchor", a); refreshOverlay(); renderTab() }
        seek(c, t("x_off"), 0, 300, Mods.x(this, m)) { Cfg.putInt(this, "m.$id.x", it); refreshOverlay() }
        seek(c, t("y_off"), 0, 300, Mods.y(this, m)) { Cfg.putInt(this, "m.$id.y", it); refreshOverlay() }
        seek(c, t("size"), 50, 250, Mods.scale(this, m)) { Cfg.putInt(this, "m.$id.scale", it); refreshOverlay() }
        seek(c, t("opacity"), 20, 100, Mods.opacity(this, m)) { Cfg.putInt(this, "m.$id.opacity", it); refreshOverlay() }
        c.addView(tv(t("color"), 14f, white), lp(12))
        swatches(c, Mods.color(this, m), modColors) { col -> Cfg.putInt(this, "m.$id.color", col); refreshOverlay(); renderTab() }
    }

    // ---------- Курсор ----------
    private fun cursorTab() {
        add(tv(t("cur_title"), 26f, white, true))
        add(tv(t("cur_sub"), 14f, sub))
        val c = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        head.addView(tv(t("cur_on"), 16f, white, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(sw().apply {
            isChecked = Cfg.getBool(this@MainActivity, "cur.on", false)
            setOnCheckedChangeListener { _, v -> Cfg.putBool(this@MainActivity, "cur.on", v); refreshOverlay() }
        })
        c.addView(head)

        c.addView(tv(t("cur_shape"), 14f, white), lp(14))
        val cur = Cfg.getInt(this, "cur.shape", 0)
        for (r in 0..1) {
            val rw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in 0..3) {
                val idx = r * 4 + k
                val tile = FrameLayout(this).apply {
                    background = Ui.round(this@MainActivity, if (idx == cur) Ui.withAlpha(accent(), 0x99) else soft, 10)
                    setOnClickListener {
                        Cfg.putInt(this@MainActivity, "cur.shape", idx)
                        refreshOverlay()
                        renderTab()
                    }
                }
                tile.addView(
                    CursorView(this, idx, dp(2).toFloat(), dp(4).toFloat(), white, true),
                    FrameLayout.LayoutParams(dp(40), dp(40), android.view.Gravity.CENTER)
                )
                rw.addView(tile, LinearLayout.LayoutParams(dp(64), dp(64)).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            c.addView(rw, lp(6))
        }

        seek(c, t("size"), 16, 160, Cfg.getInt(this, "cur.size", 40)) { Cfg.putInt(this, "cur.size", it); refreshOverlay() }
        seek(c, t("cur_thick"), 1, 10, Cfg.getInt(this, "cur.thick", 3)) { Cfg.putInt(this, "cur.thick", it); refreshOverlay() }
        seek(c, t("cur_gap"), 0, 30, Cfg.getInt(this, "cur.gap", 6)) { Cfg.putInt(this, "cur.gap", it); refreshOverlay() }
        seek(c, t("opacity"), 20, 100, Cfg.getInt(this, "cur.op", 100)) { Cfg.putInt(this, "cur.op", it); refreshOverlay() }
        seek(c, t("x_off"), -200, 200, Cfg.getInt(this, "cur.x", 0)) { Cfg.putInt(this, "cur.x", it); refreshOverlay() }
        seek(c, t("y_off"), -200, 200, Cfg.getInt(this, "cur.y", 0)) { Cfg.putInt(this, "cur.y", it); refreshOverlay() }

        c.addView(tv(t("color"), 14f, white), lp(14))
        swatches(c, Cfg.getInt(this, "cur.color", Color.WHITE), modColors) { col ->
            Cfg.putInt(this, "cur.color", col); refreshOverlay(); renderTab()
        }

        val ol = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        ol.addView(tv(t("cur_outline"), 14f, white), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        ol.addView(sw().apply {
            isChecked = Cfg.getBool(this@MainActivity, "cur.outline", true)
            setOnCheckedChangeListener { _, v -> Cfg.putBool(this@MainActivity, "cur.outline", v); refreshOverlay() }
        })
        c.addView(ol, lp(14))
        add(c, lp(14))
        add(tv(t("cur_note"), 12f, sub), lp(10))
    }

    // ---------- Эффекты ----------
    private fun fx() {
        add(tv(t("fx_title"), 26f, white, true))
        add(tv(t("fx_sub"), 14f, sub))
        val c = card()
        seek(c, t("fx_dim"), 0, 80, Cfg.getInt(this, "fx.dim", 0)) { Cfg.putInt(this, "fx.dim", it); refreshOverlay() }
        seek(c, t("fx_vig"), 0, 100, Cfg.getInt(this, "fx.vig", 0)) { Cfg.putInt(this, "fx.vig", it); refreshOverlay() }
        c.addView(tv(t("fx_tint"), 14f, white), lp(14))
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("tint_off", "tint_warm", "tint_cool")
        val cur = Cfg.getInt(this, "fx.tint", 0)
        for ((i, k) in names.withIndex()) {
            r.addView(
                btn(t(k), if (i == cur) accent() else soft) {
                    Cfg.putInt(this, "fx.tint", i); refreshOverlay(); renderTab()
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            )
        }
        c.addView(r, lp(8))
        seek(c, t("fx_amt"), 0, 100, Cfg.getInt(this, "fx.amt", 40)) { Cfg.putInt(this, "fx.amt", it); refreshOverlay() }
        add(c, lp(14))
    }

    // ---------- Сессии ----------
    private fun sessions() {
        add(tv(t("sess_title"), 26f, white, true))
        val list = SessionLog.last(this, 20)
        if (list.isEmpty()) {
            add(tv(t("sess_empty"), 14f, sub), lp(10))
            return
        }
        for (line in list) {
            val p = line.split(',')
            if (p.size >= 6) {
                val c = card()
                c.addView(tv(String.format(t("sess_row"), p[0], p[1], p[2], p[4], p[5]), 13f, white))
                add(c, lp(8))
            }
        }
    }

    // ---------- Настройки ----------
    private fun settings() {
        add(tv(t("set_title"), 26f, white, true))


        val look = card()
        look.addView(tv(t("set_accent"), 15f, white, true))
        swatches(look, accent(), accents) { col -> Cfg.putInt(this, "accent", col); refreshOverlay(); renderAll() }
        val amo = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        amo.addView(tv(t("set_amoled"), 14f, white), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        amo.addView(sw().apply {
            isChecked = Cfg.amoled(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Cfg.putBool(this@MainActivity, "amoled", v); refreshOverlay(); renderAll() }
        })
        look.addView(amo, lp(14))
        add(look, lp(12))

        val key = card()
        key.addView(tv(t("set_hotkey"), 15f, white, true))
        key.addView(tv(Cfg.keyName(Cfg.hotkey(this)), 20f, accent(), true))
        val kr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        kr.addView(btn(t("change"), accent()) { captureHotkey() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        kr.addView(btn(t("reset_key"), soft) { Cfg.putInt(this, "hotkey", KeyEvent.KEYCODE_SHIFT_RIGHT); renderTab() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        key.addView(kr, lp(8))
        add(key, lp(12))

        val pan = card()
        pan.addView(tv(t("set_panel"), 15f, white, true))
        grid(pan, Cfg.getInt(this, "panel.anchor", 2)) { a -> Cfg.putInt(this, "panel.anchor", a); refreshOverlay(); renderTab() }
        seek(pan, t("panel_scale"), 60, 160, Cfg.getInt(this, "panel.scale", 100)) { Cfg.putInt(this, "panel.scale", it); refreshOverlay() }
        seek(pan, t("panel_opacity"), 30, 100, Cfg.getInt(this, "panel.opacity", 92)) { Cfg.putInt(this, "panel.opacity", it); refreshOverlay() }
        add(pan, lp(12))

        val sp = card()
        sp.addView(tv(t("splash_img"), 15f, white, true))
        val sr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sr.addView(btn(t("choose"), accent()) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
            @Suppress("DEPRECATION")
            startActivityForResult(i, 20)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        sr.addView(btn(t("reset_key"), soft) { File(filesDir, "splash.img").delete(); toast(t("saved")) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sp.addView(sr, lp(8))
        add(sp, lp(12))

        add(btn(t("reset_all"), soft) {
            Cfg.reset(this); I18n.init(this); refreshOverlay(); renderAll()
        }, lp(18))
        add(btn(t("logout"), 0xFF3A2430.toInt()) {
            Auth.logout(this)
            askedStorage = false
            check()
        }, lp(10))
        add(tv("Developers: smoshok & Claude", 13f, sub), lp(20))
    }

    private fun captureHotkey() {
        val d = AlertDialog.Builder(this)
            .setTitle(t("set_hotkey"))
            .setMessage(t("press_key"))
            .setNegativeButton(t("cancel"), null)
            .create()
        d.setOnKeyListener { dlg, code, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN && code != KeyEvent.KEYCODE_BACK && code != KeyEvent.KEYCODE_HOME) {
                Cfg.putInt(this, "hotkey", code)
                dlg.dismiss()
                renderTab()
                true
            } else {
                false
            }
        }
        d.show()
    }

    // ---------- элементы управления ----------
    private fun seek(parent: LinearLayout, label: String, min: Int, max: Int, cur: Int, onDone: (Int) -> Unit) {
        val lab = tv("$label: $cur", 13f, sub)
        val sb = SeekBar(this).apply {
            this.max = max - min
            progressTintList = ColorStateList.valueOf(accent())
            thumbTintList = ColorStateList.valueOf(accent())
            progress = (cur - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    lab.text = "$label: ${p + min}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    onDone((s?.progress ?: 0) + min)
                }
            })
        }
        parent.addView(lab, lp(10))
        parent.addView(sb)
    }

    private fun swatches(parent: LinearLayout, cur: Int, colors: IntArray, onPick: (Int) -> Unit) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (col in colors) {
            val v = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(col)
                    if (col == cur) setStroke(dp(3), if (col == Color.WHITE) 0xFF35B8F0.toInt() else Color.WHITE)
                }
                setOnClickListener { onPick(col) }
            }
            r.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) })
        }
        parent.addView(r, lp(8))
    }

    /** Сетка 3x3 для выбора положения на экране. */
    private fun grid(parent: LinearLayout, cur: Int, onPick: (Int) -> Unit) {
        val g = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (r in 0..2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..2) {
                val a = r * 3 + c
                row.addView(
                    btn("", if (a == cur) accent() else soft) { onPick(a) },
                    LinearLayout.LayoutParams(dp(48), dp(34)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                )
            }
            g.addView(row)
        }
        parent.addView(g, lp(8))
    }
}

package com.rbx.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var sidebar: LinearLayout
    private lateinit var content: LinearLayout
    private var tab = 0
    private var openMod: String? = null
    private var askedStorage = false
    private var loginOpen = false

    private val white = Color.WHITE
    private val sub = 0xFF9AA3B2.toInt()
    private val green = 0xFF4ADE80.toInt()
    private val soft = 0xFF2A2F3A.toInt()
    private val accents = intArrayOf(
        0xFF5B8CFF.toInt(), 0xFF8B5CF6.toInt(), 0xFF22C55E.toInt(),
        0xFFEF4444.toInt(), 0xFFF59E0B.toInt(), 0xFFEC4899.toInt()
    )
    private val modColors = intArrayOf(0xFFFFFFFF.toInt()) + accents

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun t(k: String) = I18n.t(k)
    private fun accent() = Cfg.accent(this)
    private fun bgc() = if (Cfg.amoled(this)) 0xFF000000.toInt() else 0xFF0B0C12.toInt()
    private fun cardc() = if (Cfg.amoled(this)) 0xFF0F0F11.toInt() else 0xFF151722.toInt()
    private fun sidec() = if (Cfg.amoled(this)) 0xFF050506.toInt() else 0xFF0D0E15.toInt()
    private fun tv(s: String, sp: Float, c: Int, b: Boolean = false) = Ui.tv(this, s, sp, c, b)
    private fun btn(s: String, bg: Int, f: () -> Unit) = Ui.btn(this, s, bg, f)
    private fun lp(top: Int, hDp: Int = 0): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        if (hDp == 0) ViewGroup.LayoutParams.WRAP_CONTENT else dp(hDp)
    ).apply { topMargin = dp(top) }

    private fun add(v: View, p: ViewGroup.LayoutParams? = null) {
        if (p != null) content.addView(v, p) else content.addView(v)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun refreshOverlay() { KeyService.instance?.refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        I18n.init(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val sw = if (resources.configuration.screenWidthDp >= 600) 210 else 140
        sidebar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(28), dp(14), dp(18))
        }
        root.addView(sidebar, LinearLayout.LayoutParams(dp(sw), ViewGroup.LayoutParams.MATCH_PARENT))
        val sv = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
        }
        sv.addView(content)
        root.addView(sv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        check()
    }

    /** 1) обязательный вход в Roblox  2) запрос доступа к файлам  3) отрисовка */
    private fun check() {
        if (!Auth.hasSession()) {
            if (!loginOpen) {
                loginOpen = true
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(this, LoginActivity::class.java), 10)
            }
            return
        }
        if (!askedStorage && !hasStorage()) {
            askedStorage = true
            requestStorage()
        }
        renderAll()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10) {
            loginOpen = false
            if (resultCode != RESULT_OK && !Auth.hasSession()) finish()
        } else if (requestCode == 20 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { inp ->
                    File(filesDir, "splash.img").outputStream().use { out -> inp.copyTo(out) }
                }
                toast(t("saved"))
            } catch (e: Exception) {
                toast("Error")
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        @Suppress("DEPRECATION")
        super.onRequestPermissionsResult(code, perms, res)
        renderAll()
    }

    // ---------- файлы / служба ----------
    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 11)
        }
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.split(':').any { it.contains(packageName) && it.contains("KeyService") }
    }

    private fun launchRoblox() {
        val i = packageManager.getLaunchIntentForPackage(KeyService.ROBLOX)
        if (i != null) {
            startActivity(i)
        } else {
            toast(t("not_installed"))
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${KeyService.ROBLOX}")))
            } catch (e: Exception) {
                // нет магазина
            }
        }
    }

    // ---------- каркас ----------
    private fun renderAll() {
        root.setBackgroundColor(bgc())
        renderNav()
        renderTab()
    }

    private fun renderNav() {
        sidebar.removeAllViews()
        sidebar.setBackgroundColor(sidec())
        sidebar.addView(tv("RBX", 32f, accent(), true))
        sidebar.addView(tv("LAUNCHER", 14f, white, true))
        sidebar.addView(View(this), LinearLayout.LayoutParams(1, dp(22)))
        val keys = listOf("nav_home", "nav_mods", "nav_fx", "nav_sessions", "nav_settings")
        for ((i, k) in keys.withIndex()) {
            val sel = i == tab
            val item = tv(t(k), 15f, if (sel) white else sub, sel).apply {
                setPadding(dp(12), dp(12), dp(12), dp(12))
                if (sel) background = Ui.round(this@MainActivity, Ui.withAlpha(accent(), 0x55), 10)
                setOnClickListener { tab = i; renderTab(); renderNav() }
            }
            sidebar.addView(item, lp(4))
        }
        sidebar.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        sidebar.addView(tv("Developers", 11f, sub))
        sidebar.addView(tv("smoshok & Claude", 14f, white, true))
    }

    private fun renderTab() {
        content.removeAllViews()
        when (tab) {
            0 -> home()
            1 -> mods()
            2 -> fx()
            3 -> sessions()
            else -> settings()
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = Ui.round(this@MainActivity, cardc(), 12)
    }

    private fun row(title: String, ok: Boolean, btnText: String, action: () -> Unit) {
        val c = card()
        c.addView(tv(title + if (ok) "  ✅" else "  ❌", 15f, white))
        if (!ok) c.addView(btn(btnText, accent()) { action() }, lp(8))
        add(c, lp(10))
    }

    // ---------- Главная ----------
    private fun home() {
        add(tv(String.format(t("hello"), Auth.username(this)), 26f, white, true))
        add(tv(t("hello_sub"), 15f, green))
        add(btn("▶  " + t("launch"), accent()) { launchRoblox() }, lp(18, 60))
        row(t("files_access"), hasStorage(), t("grant")) { requestStorage() }
        row(t("hotkey_svc"), a11yOn(), t("enable")) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast(t("a11y_toast"))
        }
        add(tv(String.format(t("hint_use"), Cfg.keyName(Cfg.hotkey(this))), 14f, sub), lp(14))
        add(btn(t("toggle_panel"), soft) {
            val s = KeyService.instance
            if (s != null) s.togglePanel() else toast(t("need_service"))
        }, lp(12))
    }

    // ---------- Моды ----------
    private fun mods() {
        add(tv(t("mods_title"), 26f, white, true))
        add(tv(t("mods_sub"), 14f, sub))
        for (m in Mods.all) modCard(m)
    }

    private fun modCard(m: ModDef) {
        val c = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv(t("mod_${m.id}"), 16f, white, true))
        texts.addView(tv(t("mod_${m.id}_d"), 12f, sub))
        head.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Switch(this).apply {
            isChecked = Mods.on(this@MainActivity, m)
            setOnCheckedChangeListener { _, v ->
                Mods.setOn(this@MainActivity, m, v)
                refreshOverlay()
            }
        })
        c.addView(head)
        val open = openMod == m.id
        c.addView(btn(if (open) "▲" else "⚙  " + t("change"), soft) {
            openMod = if (open) null else m.id
            renderTab()
        }, lp(8))
        if (open) modSettings(c, m)
        add(c, lp(12))
    }

    private fun modSettings(c: LinearLayout, m: ModDef) {
        val id = m.id
        c.addView(tv(t("position"), 14f, white), lp(10))
        grid(c, Mods.anchor(this, m)) { a -> Cfg.putInt(this, "m.$id.anchor", a); refreshOverlay(); renderTab() }
        seek(c, t("x_off"), 0, 300, Mods.x(this, m)) { Cfg.putInt(this, "m.$id.x", it); refreshOverlay() }
        seek(c, t("y_off"), 0, 300, Mods.y(this, m)) { Cfg.putInt(this, "m.$id.y", it); refreshOverlay() }
        seek(c, t("size"), 50, 250, Mods.scale(this, m)) { Cfg.putInt(this, "m.$id.scale", it); refreshOverlay() }
        seek(c, t("opacity"), 20, 100, Mods.opacity(this, m)) { Cfg.putInt(this, "m.$id.opacity", it); refreshOverlay() }
        c.addView(tv(t("color"), 14f, white), lp(12))
        swatches(c, Mods.color(this, m), modColors) { col -> Cfg.putInt(this, "m.$id.color", col); refreshOverlay(); renderTab() }
    }

    // ---------- Эффекты ----------
    private fun fx() {
        add(tv(t("fx_title"), 26f, white, true))
        add(tv(t("fx_sub"), 14f, sub))
        val c = card()
        seek(c, t("fx_dim"), 0, 80, Cfg.getInt(this, "fx.dim", 0)) { Cfg.putInt(this, "fx.dim", it); refreshOverlay() }
        seek(c, t("fx_vig"), 0, 100, Cfg.getInt(this, "fx.vig", 0)) { Cfg.putInt(this, "fx.vig", it); refreshOverlay() }
        c.addView(tv(t("fx_tint"), 14f, white), lp(14))
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("tint_off", "tint_warm", "tint_cool")
        val cur = Cfg.getInt(this, "fx.tint", 0)
        for ((i, k) in names.withIndex()) {
            r.addView(
                btn(t(k), if (i == cur) accent() else soft) {
                    Cfg.putInt(this, "fx.tint", i); refreshOverlay(); renderTab()
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            )
        }
        c.addView(r, lp(8))
        seek(c, t("fx_amt"), 0, 100, Cfg.getInt(this, "fx.amt", 40)) { Cfg.putInt(this, "fx.amt", it); refreshOverlay() }
        add(c, lp(14))
    }

    // ---------- Сессии ----------
    private fun sessions() {
        add(tv(t("sess_title"), 26f, white, true))
        val list = SessionLog.last(this, 20)
        if (list.isEmpty()) {
            add(tv(t("sess_empty"), 14f, sub), lp(10))
            return
        }
        for (line in list) {
            val p = line.split(',')
            if (p.size >= 6) {
                val c = card()
                c.addView(tv(String.format(t("sess_row"), p[0], p[1], p[2], p[4], p[5]), 13f, white))
                add(c, lp(8))
            }
        }
    }

    // ---------- Настройки ----------
    private fun settings() {
        add(tv(t("set_title"), 26f, white, true))

        val lang = card()
        lang.addView(tv(t("set_lang"), 15f, white, true))
        val lr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (l in listOf("ru", "en")) {
            lr.addView(
                btn(t("lang_$l"), if (I18n.current() == l) accent() else soft) {
                    I18n.set(this, l); refreshOverlay(); renderAll()
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            )
        }
        lang.addView(lr, lp(8))
        add(lang, lp(14))

        val look = card()
        look.addView(tv(t("set_accent"), 15f, white, true))
        swatches(look, accent(), accents) { col -> Cfg.putInt(this, "accent", col); refreshOverlay(); renderAll() }
        val amo = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        amo.addView(tv(t("set_amoled"), 14f, white), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        amo.addView(Switch(this).apply {
            isChecked = Cfg.amoled(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Cfg.putBool(this@MainActivity, "amoled", v); refreshOverlay(); renderAll() }
        })
        look.addView(amo, lp(14))
        add(look, lp(12))

        val key = card()
        key.addView(tv(t("set_hotkey"), 15f, white, true))
        key.addView(tv(Cfg.keyName(Cfg.hotkey(this)), 20f, accent(), true))
        val kr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        kr.addView(btn(t("change"), accent()) { captureHotkey() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        kr.addView(btn(t("reset_key"), soft) { Cfg.putInt(this, "hotkey", KeyEvent.KEYCODE_SHIFT_RIGHT); renderTab() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        key.addView(kr, lp(8))
        add(key, lp(12))

        val pan = card()
        pan.addView(tv(t("set_panel"), 15f, white, true))
        grid(pan, Cfg.getInt(this, "panel.anchor", 2)) { a -> Cfg.putInt(this, "panel.anchor", a); refreshOverlay(); renderTab() }
        seek(pan, t("panel_scale"), 60, 160, Cfg.getInt(this, "panel.scale", 100)) { Cfg.putInt(this, "panel.scale", it); refreshOverlay() }
        seek(pan, t("panel_opacity"), 30, 100, Cfg.getInt(this, "panel.opacity", 92)) { Cfg.putInt(this, "panel.opacity", it); refreshOverlay() }
        add(pan, lp(12))

        val sp = card()
        sp.addView(tv(t("splash_img"), 15f, white, true))
        val sr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sr.addView(btn(t("choose"), accent()) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
            @Suppress("DEPRECATION")
            startActivityForResult(i, 20)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        sr.addView(btn(t("reset_key"), soft) { File(filesDir, "splash.img").delete(); toast(t("saved")) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sp.addView(sr, lp(8))
        add(sp, lp(12))

        add(btn(t("reset_all"), soft) {
            Cfg.reset(this); I18n.init(this); refreshOverlay(); renderAll()
        }, lp(18))
        add(btn(t("logout"), 0xFF3A2430.toInt()) {
            Auth.logout(this)
            askedStorage = false
            check()
        }, lp(10))
        add(tv("Developers: smoshok & Claude", 13f, sub), lp(20))
    }

    private fun captureHotkey() {
        val d = AlertDialog.Builder(this)
            .setTitle(t("set_hotkey"))
            .setMessage(t("press_key"))
            .setNegativeButton(t("cancel"), null)
            .create()
        d.setOnKeyListener { dlg, code, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN && code != KeyEvent.KEYCODE_BACK && code != KeyEvent.KEYCODE_HOME) {
                Cfg.putInt(this, "hotkey", code)
                dlg.dismiss()
                renderTab()
                true
            } else {
                false
            }
        }
        d.show()
    }

    // ---------- элементы управления ----------
    private fun seek(parent: LinearLayout, label: String, min: Int, max: Int, cur: Int, onDone: (Int) -> Unit) {
        val lab = tv("$label: $cur", 13f, sub)
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = (cur - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    lab.text = "$label: ${p + min}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    onDone((s?.progress ?: 0) + min)
                }
            })
        }
        parent.addView(lab, lp(10))
        parent.addView(sb)
    }

    private fun swatches(parent: LinearLayout, cur: Int, colors: IntArray, onPick: (Int) -> Unit) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (col in colors) {
            val v = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(col)
                    if (col == cur) setStroke(dp(3), if (col == Color.WHITE) 0xFF5B8CFF.toInt() else Color.WHITE)
                }
                setOnClickListener { onPick(col) }
            }
            r.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) })
        }
        parent.addView(r, lp(8))
    }

    /** Сетка 3x3 для выбора положения на экране. */
    private fun grid(parent: LinearLayout, cur: Int, onPick: (Int) -> Unit) {
        val g = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (r in 0..2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..2) {
                val a = r * 3 + c
                row.addView(
                    btn("", if (a == cur) accent() else soft) { onPick(a) },
                    LinearLayout.LayoutParams(dp(48), dp(34)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                )
            }
            g.addView(row)
        }
        parent.addView(g, lp(8))
    }
}

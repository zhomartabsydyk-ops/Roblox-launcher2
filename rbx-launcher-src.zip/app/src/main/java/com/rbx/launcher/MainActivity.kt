package com.rbx.launcher

import android.app.Activity
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var askedStorage = false
    private var loginOpen = false

    private val white = Color.WHITE
    private val gray = 0xFFB8C0CC.toInt()
    private val green = 0xFF4ADE80.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF0F1115.toInt())
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        check()
    }

    /** 1) обязательный вход в Roblox  2) запрос доступа к файлам  3) отрисовка экрана */
    private fun check() {
        if (!Auth.hasSession()) {
            if (!loginOpen) {
                loginOpen = true
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(this, LoginActivity::class.java), 10)
            }
            return
        }
        if (!askedStorage && !hasStorage()) {
            askedStorage = true
            requestStorage()
        }
        render()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10) {
            loginOpen = false
            if (resultCode != RESULT_OK && !Auth.hasSession()) finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        @Suppress("DEPRECATION")
        super.onRequestPermissionsResult(code, perms, res)
        render()
    }

    // ---------- файлы ----------
    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 11
            )
        }
    }

    // ---------- Правый Shift (специальные возможности) ----------
    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.split(':').any { it.contains(packageName) && it.contains("KeyService") }
    }

    private fun launchRoblox() {
        val i = packageManager.getLaunchIntentForPackage(KeyService.ROBLOX)
        if (i != null) {
            startActivity(i)
        } else {
            Toast.makeText(this, "Roblox не установлен", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${KeyService.ROBLOX}")))
            } catch (e: Exception) {
                // нет магазина
            }
        }
    }

    // ---------- UI ----------
    private fun render() {
        root.removeAllViews()
        root.addView(tv("RBX Launcher", 28, white, true))
        root.addView(tv("Аккаунт: ${Auth.username(this)}", 16, green))

        root.addView(mkBtn("▶  Запустить Roblox", 0xFF2B6BFF.toInt()) { launchRoblox() }, lp(16))

        row("Доступ к файлам (журнал сессий)", hasStorage(), "Выдать") { requestStorage() }
        row("Панель по правому Shift", a11yOn(), "Включить") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Найди «RBX Launcher» и включи", Toast.LENGTH_LONG).show()
        }

        root.addView(mkBtn("Показать / скрыть панель", 0xFF2A2F3A.toInt()) {
            val s = KeyService.instance
            if (s != null) s.togglePanel()
            else Toast.makeText(this, "Сначала включи «Панель по правому Shift»", Toast.LENGTH_LONG).show()
        }, lp(12))

        val sessions = SessionLog.last(this, 5)
        root.addView(tv("Последние игровые сессии", 18, white, true), lp(22))
        if (sessions.isEmpty()) {
            root.addView(tv("Пока пусто. Запиши первую: открой Roblox и поиграй больше минуты.", 14, gray))
        } else {
            for (line in sessions) {
                val p = line.split(',')
                if (p.size >= 6) {
                    root.addView(
                        tv("${p[0]} • ${p[1]} мин • пинг ${p[2]} мс • ${p[4]}°C • ОЗУ мин ${p[5]} МБ", 13, gray)
                    )
                }
            }
        }

        root.addView(tv("Как пользоваться", 18, white, true), lp(22))
        root.addView(
            tv(
                "1. Включи «Панель по правому Shift» (Android спросит вручную).\n" +
                    "2. Запусти Roblox.\n" +
                    "3. Нажми правый Shift - появится панель с пингом, ОЗУ, температурой, " +
                    "кнопкой «Освободить ОЗУ» и затемнением экрана. Ещё раз Shift - скрыть.",
                14, gray
            )
        )

        root.addView(mkBtn("Выйти из аккаунта", 0xFF3A2430.toInt()) {
            Auth.logout(this)
            askedStorage = false
            check()
        }, lp(26))
    }

    private fun row(title: String, ok: Boolean, btn: String, action: () -> Unit) {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(0xFF1A1D24.toInt())
                cornerRadius = dp(12).toFloat()
            }
        }
        l.addView(tv(title + (if (ok) "  ✅" else "  ❌"), 15, white))
        if (!ok) l.addView(mkBtn(btn, 0xFF2B6BFF.toInt()) { action() }, lp(8))
        root.addView(l, lp(10))
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun tv(text: String, sp: Int, color: Int, bold: Boolean = false): TextView = tv(text, sp.toFloat(), color, bold)

    private fun mkBtn(text: String, bg: Int, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(white)
        background = GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(12).toFloat()
        }
        setOnClickListener { onClick() }
    }

    private fun lp(top: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }
}

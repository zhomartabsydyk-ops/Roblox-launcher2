package com.rbx.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import java.util.Random

/** Звёздный фон в стиле Lunar: тёмный градиент и редкие звёзды. */
class StarsView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val n = 150
    private val xs = FloatArray(n)
    private val ys = FloatArray(n)
    private val rs = FloatArray(n)
    private val al = IntArray(n)

    init {
        val r = Random(7)
        for (i in 0 until n) {
            xs[i] = r.nextFloat()
            ys[i] = r.nextFloat()
            rs[i] = 0.6f + r.nextFloat() * 1.6f
            al[i] = 70 + r.nextInt(185)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF090D19.toInt(), 0xFF1B2540.toInt(), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        p.style = Paint.Style.FILL
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
        p.shader = null
        val d = resources.displayMetrics.density
        for (i in 0 until n) {
            p.color = (al[i] shl 24) or 0xDDE6FF
            c.drawCircle(xs[i] * width, ys[i] * height, rs[i] * d, p)
        }
        p.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), 0xFF090D19.toInt(), 0xFF1B2540.toInt(), Shader.TileMode.CLAMP)
    }
}

/** Контурные иконки в стиле Lunar (рисуются кодом, без картинок). */
class IconView(ctx: Context, private val type: Int, private val color: Int) : View(ctx) {
    companion object {
        const val ROCKET = 0
        const val GAMEPAD = 1
        const val GRID = 2
        const val CROSSHAIR = 3
        const val SPARKLE = 4
        const val CLOCK = 5
        const val SLIDERS = 6
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@IconView.color
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val s = width.toFloat()
        p.style = Paint.Style.STROKE
        p.strokeWidth = s * 0.075f
        fun x(v: Float) = v * s
        when (type) {
            ROCKET -> {
                val body = Path().apply {
                    moveTo(x(.5f), x(.08f))
                    cubicTo(x(.74f), x(.24f), x(.78f), x(.50f), x(.70f), x(.68f))
                    lineTo(x(.30f), x(.68f))
                    cubicTo(x(.22f), x(.50f), x(.26f), x(.24f), x(.5f), x(.08f))
                    close()
                }
                c.drawPath(body, p)
                c.drawCircle(x(.5f), x(.40f), x(.08f), p)
                val fins = Path().apply {
                    moveTo(x(.31f), x(.58f)); lineTo(x(.16f), x(.80f)); lineTo(x(.34f), x(.74f))
                    moveTo(x(.69f), x(.58f)); lineTo(x(.84f), x(.80f)); lineTo(x(.66f), x(.74f))
                    moveTo(x(.42f), x(.78f)); lineTo(x(.5f), x(.93f)); lineTo(x(.58f), x(.78f))
                }
                c.drawPath(fins, p)
            }
            GAMEPAD -> {
                c.drawRoundRect(RectF(x(.08f), x(.28f), x(.92f), x(.72f)), x(.2f), x(.2f), p)
                c.drawLine(x(.22f), x(.50f), x(.38f), x(.50f), p)
                c.drawLine(x(.30f), x(.42f), x(.30f), x(.58f), p)
                p.style = Paint.Style.FILL
                c.drawCircle(x(.66f), x(.45f), x(.04f), p)
                c.drawCircle(x(.77f), x(.55f), x(.04f), p)
            }
            GRID -> {
                val r = x(.07f)
                c.drawRoundRect(RectF(x(.14f), x(.14f), x(.43f), x(.43f)), r, r, p)
                c.drawRoundRect(RectF(x(.57f), x(.14f), x(.86f), x(.43f)), r, r, p)
                c.drawRoundRect(RectF(x(.14f), x(.57f), x(.43f), x(.86f)), r, r, p)
                c.drawRoundRect(RectF(x(.57f), x(.57f), x(.86f), x(.86f)), r, r, p)
            }
            CROSSHAIR -> {
                c.drawCircle(x(.5f), x(.5f), x(.26f), p)
                c.drawLine(x(.5f), x(.10f), x(.5f), x(.30f), p)
                c.drawLine(x(.5f), x(.70f), x(.5f), x(.90f), p)
                c.drawLine(x(.10f), x(.5f), x(.30f), x(.5f), p)
                c.drawLine(x(.70f), x(.5f), x(.90f), x(.5f), p)
                p.style = Paint.Style.FILL
                c.drawCircle(x(.5f), x(.5f), x(.045f), p)
            }
            SPARKLE -> {
                val star = Path().apply {
                    moveTo(x(.5f), x(.10f))
                    quadTo(x(.55f), x(.45f), x(.90f), x(.5f))
                    quadTo(x(.55f), x(.55f), x(.5f), x(.90f))
                    quadTo(x(.45f), x(.55f), x(.10f), x(.5f))
                    quadTo(x(.45f), x(.45f), x(.5f), x(.10f))
                    close()
                }
                c.drawPath(star, p)
            }
            CLOCK -> {
                c.drawCircle(x(.5f), x(.5f), x(.37f), p)
                c.drawLine(x(.5f), x(.5f), x(.5f), x(.27f), p)
                c.drawLine(x(.5f), x(.5f), x(.67f), x(.59f), p)
            }
            else -> {
                c.drawLine(x(.14f), x(.27f), x(.86f), x(.27f), p)
                c.drawLine(x(.14f), x(.50f), x(.86f), x(.50f), p)
                c.drawLine(x(.14f), x(.73f), x(.86f), x(.73f), p)
                p.style = Paint.Style.FILL
                c.drawCircle(x(.35f), x(.27f), x(.075f), p)
                c.drawCircle(x(.65f), x(.50f), x(.075f), p)
                c.drawCircle(x(.45f), x(.73f), x(.075f), p)
            }
        }
    }
}

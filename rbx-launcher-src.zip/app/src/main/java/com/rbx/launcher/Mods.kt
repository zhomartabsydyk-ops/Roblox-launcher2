package com.rbx.launcher

import android.content.Context
import android.view.Gravity

class ModDef(val id: String, val anchor: Int, val x: Int, val y: Int, val defOn: Boolean)

object Mods {
    val all = listOf(
        ModDef("keys", 6, 16, 16, true),
        ModDef("ping", 0, 12, 12, true),
        ModDef("ram", 0, 12, 48, false),
        ModDef("battery", 0, 12, 84, false),
        ModDef("session", 0, 12, 120, false),
        ModDef("clock", 1, 0, 12, false)
    )

    fun on(c: Context, m: ModDef) = Cfg.getBool(c, "m.${m.id}.on", m.defOn)
    fun setOn(c: Context, m: ModDef, v: Boolean) = Cfg.putBool(c, "m.${m.id}.on", v)
    fun anchor(c: Context, m: ModDef) = Cfg.getInt(c, "m.${m.id}.anchor", m.anchor)
    fun x(c: Context, m: ModDef) = Cfg.getInt(c, "m.${m.id}.x", m.x)
    fun y(c: Context, m: ModDef) = Cfg.getInt(c, "m.${m.id}.y", m.y)
    fun scale(c: Context, m: ModDef) = Cfg.getInt(c, "m.${m.id}.scale", 100)
    fun opacity(c: Context, m: ModDef) = Cfg.getInt(c, "m.${m.id}.opacity", 90)
    fun color(c: Context, m: ModDef) = Cfg.getInt(c, "m.${m.id}.color", 0xFFFFFFFF.toInt())

    /** 0..8: ряды сверху вниз, колонки слева направо. */
    fun gravity(a: Int): Int {
        val v = when (a / 3) {
            0 -> Gravity.TOP
            1 -> Gravity.CENTER_VERTICAL
            else -> Gravity.BOTTOM
        }
        val h = when (a % 3) {
            0 -> Gravity.START
            1 -> Gravity.CENTER_HORIZONTAL
            else -> Gravity.END
        }
        return v or h
    }
}

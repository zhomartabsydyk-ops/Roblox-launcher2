package com.rbx.launcher

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private typealias LP = WindowManager.LayoutParams

/**
 * Служба специальных возможностей: ловит правый Shift и рисует панель поверх Roblox
 * (окно типа TYPE_ACCESSIBILITY_OVERLAY - отдельное разрешение «поверх других окон» не нужно).
 * Содержимое экрана и вводимый текст не читаются; клавиша Shift в игру пропускается как обычно.
 */
class KeyService : AccessibilityService() {

    companion object {
        const val ROBLOX = "com.roblox.client"
        @Volatile
        var instance: KeyService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var panel: View? = null
    private var infoText: TextView? = null
    private var dimView: View? = null
    private var dimLevel = 0
    private val dimAlpha = intArrayOf(0, 77, 128, 179)
    private val dimNames = arrayOf("выкл", "30%", "50%", "70%")

    private var shiftPending = false

    // статистика сессии
    private var sessionStart = 0L
    private val pings = ArrayList<Int>()
    private var maxTemp = 0f
    private var minFree = Long.MAX_VALUE
    private var lastPing = -1
    private var battery = -1
    private var temp = 0f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- жизненный цикл ----------
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        h.post(tick)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        h.removeCallbacksAndMessages(null)
        endSession()
        hidePanel()
        removeDim()
        instance = null
    }

    override fun onInterrupt() {}

    // ---------- правый Shift ----------
    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_SHIFT_RIGHT) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                if (e.repeatCount == 0) shiftPending = true
            } else if (e.action == KeyEvent.ACTION_UP && shiftPending) {
                shiftPending = false
                h.post { togglePanel() }
            }
        } else if (e.action == KeyEvent.ACTION_DOWN) {
            shiftPending = false // Shift использовали в комбинации - не открываем панель
        }
        return false // клавишу не «съедаем», Roblox получает её как обычно
    }

    // ---------- определяем, запущен ли Roblox ----------
    private val endRunnable = Runnable { endSession() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == ROBLOX) {
            h.removeCallbacks(endRunnable)
            if (sessionStart == 0L) startSession()
        } else if (sessionStart > 0 && pkg != packageName && pkg != "com.android.systemui") {
            h.removeCallbacks(endRunnable)
            h.postDelayed(endRunnable, 60_000) // ушёл из игры больше чем на минуту - сессия закончена
        }
    }

    private fun startSession() {
        sessionStart = SystemClock.elapsedRealtime()
        pings.clear()
        maxTemp = 0f
        minFree = Long.MAX_VALUE
    }

    private fun endSession() {
        if (sessionStart == 0L) return
        val sec = (SystemClock.elapsedRealtime() - sessionStart) / 1000
        if (sec >= 60) {
            val ok = pings.filter { it >= 0 }
            val avg = if (ok.isEmpty()) 0 else ok.sum() / ok.size
            val mx = ok.maxOrNull() ?: 0
            val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
            val ram = if (minFree == Long.MAX_VALUE) 0 else minFree
            val line = "$date,${sec / 60},$avg,$mx,${"%.1f".format(Locale.US, maxTemp)},$ram"
            SessionLog.append(this, line)
        }
        sessionStart = 0L
    }

    // ---------- периодический опрос ----------
    private val tick = object : Runnable {
        override fun run() {
            if (panel != null || sessionStart > 0) sample()
            h.postDelayed(this, 3000)
        }
    }

    private fun sample() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            battery = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
            temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            if (sessionStart > 0 && temp > maxTemp) maxTemp = temp
        }
        val free = freeMb()
        if (sessionStart > 0 && free < minFree) minFree = free

        Thread {
            val ms = pingRoblox()
            h.post {
                lastPing = ms
                if (sessionStart > 0) pings.add(ms)
                updateInfo()
            }
        }.start()
        updateInfo()
    }

    private fun pingRoblox(): Int {
        val t = System.nanoTime()
        return try {
            Socket().use { it.connect(InetSocketAddress("www.roblox.com", 443), 2000) }
            ((System.nanoTime() - t) / 1_000_000).toInt()
        } catch (e: Exception) {
            -1
        }
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi
    }

    private fun freeMb(): Long = memInfo().availMem / 1048576
    private fun totalMb(): Long = memInfo().totalMem / 1048576

    private fun thermalName(): String = try {
        when ((getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus) {
            0 -> "норма"
            1 -> "лёгкий"
            2 -> "умеренный"
            3 -> "сильный"
            4 -> "критичный"
            else -> "аварийный"
        }
    } catch (e: Exception) {
        "?"
    }

    private fun refreshHz(): Int = try {
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate?.toInt() ?: 0
    } catch (e: Exception) {
        0
    }

    private fun sessionTime(): String {
        if (sessionStart == 0L) return "Roblox не запущен"
        val s = (SystemClock.elapsedRealtime() - sessionStart) / 1000
        return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun infoString(): String =
        "ОЗУ свободно: ${freeMb()} / ${totalMb()} МБ\n" +
            "Батарея: $battery%  •  ${"%.1f".format(temp)}°C\n" +
            "Нагрев: ${thermalName()}\n" +
            "Пинг до Roblox: ${if (lastPing >= 0) "$lastPing мс" else "—"}\n" +
            "Экран: ${refreshHz()} Гц\n" +
            "Сессия: ${sessionTime()}"

    private fun updateInfo() {
        infoText?.text = infoString()
    }

    // ---------- панель ----------
    fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }

    private fun btn(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(0xFF2B6BFF.toInt())
            cornerRadius = dp(10).toFloat()
        }
        setOnClickListener { onClick() }
    }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(0xEE1A1D24.toInt())
                cornerRadius = dp(14).toFloat()
            }
        }
        box.addView(TextView(this).apply {
            text = "RBX Launcher  •  ${Auth.username(this@KeyService)}"
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        })
        val info = TextView(this).apply {
            setTextColor(0xFFB8C0CC.toInt())
            textSize = 13f
            setPadding(0, dp(8), 0, dp(8))
        }
        infoText = info
        box.addView(info)
        box.addView(btn("🚀 Освободить ОЗУ") { boost() })
        box.addView(btn("🌙 Затемнение: ${dimNames[dimLevel]}") { cycleDim() })
        box.addView(btn("Закрыть (правый Shift)") { hidePanel() })

        val lp = LP(
            dp(300), LP.WRAP_CONTENT,
            LP.TYPE_ACCESSIBILITY_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(12)
        }
        try {
            wm.addView(box, lp)
            panel = box
            sample()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось показать панель", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hidePanel() {
        panel?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // уже убрано
            }
        }
        panel = null
        infoText = null
    }

    // ---------- затемнение экрана (экономит батарею, меньше нагрев) ----------
    private fun cycleDim() {
        dimLevel = (dimLevel + 1) % dimAlpha.size
        removeDim()
        if (dimLevel > 0) {
            val v = View(this)
            v.setBackgroundColor(Color.argb(dimAlpha[dimLevel], 0, 0, 0))
            val lp = LP(
                LP.MATCH_PARENT, LP.MATCH_PARENT,
                LP.TYPE_ACCESSIBILITY_OVERLAY,
                LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            try {
                wm.addView(v, lp)
                dimView = v
            } catch (e: Exception) {
                // ignore
            }
        }
        // перерисовываем панель, чтобы она была поверх затемнения
        if (panel != null) {
            hidePanel()
            showPanel()
        }
    }

    private fun removeDim() {
        dimView?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // уже убрано
            }
        }
        dimView = null
    }

    // ---------- освободить ОЗУ ----------
    private fun boost() {
        val before = freeMb()
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val skip = HashSet<String>()
        skip.add(ROBLOX)
        skip.add(packageName)
        skip.add("com.android.systemui")
        skip.add("android")
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.resolveActivity(home, 0)?.activityInfo?.packageName?.let { skip.add(it) }
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')?.let { skip.add(it) }

        var n = 0
        for (a in packageManager.getInstalledApplications(0)) {
            if (a.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            if (a.packageName in skip) continue
            try {
                am.killBackgroundProcesses(a.packageName)
                n++
            } catch (e: Exception) {
                // пропускаем
            }
        }
        h.postDelayed({
            val after = freeMb()
            val diff = after - before
            Toast.makeText(
                this,
                "Закрыто фоновых приложений: $n. ОЗУ: ${if (diff >= 0) "+" else ""}$diff МБ",
                Toast.LENGTH_LONG
            ).show()
            updateInfo()
        }, 1200)
    }
}

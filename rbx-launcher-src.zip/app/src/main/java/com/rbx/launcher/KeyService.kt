package com.rbx.launcher

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private typealias LP = WindowManager.LayoutParams

/**
 * Служба специальных возможностей: ловит горячую клавишу и рисует панель, моды и эффекты
 * поверх Roblox (окна TYPE_ACCESSIBILITY_OVERLAY, отдельное разрешение «поверх окон» не нужно).
 * Содержимое экрана и вводимый текст не читаются; нажатия в игру пропускаются как обычно.
 */
class KeyService : AccessibilityService() {

    companion object {
        const val ROBLOX = "com.roblox.client"
        @Volatile
        var instance: KeyService? = null
    }

    private val PASS = LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE
    private val FULL = PASS or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var panel: View? = null
    private var infoText: TextView? = null
    private val widgets = ArrayList<View>()
    private val widgetText = HashMap<String, TextView>()
    private val keyViews = HashMap<Int, TextView>()
    private val fxViews = ArrayList<View>()
    private var hotPending = false

    // статистика
    private var sessionStart = 0L
    private val pings = ArrayList<Int>()
    private var maxTemp = 0f
    private var minFree = Long.MAX_VALUE
    private var lastPing = -1
    private var battery = -1
    private var temp = 0f
    private var freeCache = 0L
    private var ticks = 0

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()
    private fun t(k: String) = I18n.t(k)
    private fun accent() = Cfg.accent(this)
    private fun fmt1(f: Float) = String.format(Locale.US, "%.1f", f)

    // ---------- жизненный цикл ----------
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        I18n.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        applyAll()
        h.post(tick)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        h.removeCallbacksAndMessages(null)
        endSession()
        hidePanel()
        removeAll()
        instance = null
    }

    override fun onInterrupt() {}

    /** Вызывается из настроек: перестроить панель, моды и эффекты. */
    fun refresh() {
        h.post {
            val wasPanel = panel != null
            hidePanel()
            I18n.init(this)
            applyAll()
            if (wasPanel) showPanel()
        }
    }

    // ---------- клавиши ----------
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val hot = Cfg.hotkey(this)
        if (e.keyCode == hot) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                if (e.repeatCount == 0) hotPending = true
            } else if (e.action == KeyEvent.ACTION_UP && hotPending) {
                hotPending = false
                h.post { togglePanel() }
            }
        } else if (e.action == KeyEvent.ACTION_DOWN) {
            hotPending = false // клавишу использовали в комбинации - панель не открываем
        }
        val kv = keyViews[e.keyCode]
        if (kv != null) kv.background = capBg(e.action != KeyEvent.ACTION_UP)
        return false // клавишу не «съедаем», Roblox получает её как обычно
    }

    // ---------- определяем, запущен ли Roblox ----------
    private val endRunnable = Runnable { endSession() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == ROBLOX) {
            h.removeCallbacks(endRunnable)
            if (sessionStart == 0L) startSession()
        } else if (sessionStart > 0 && pkg != packageName && pkg != "com.android.systemui") {
            h.removeCallbacks(endRunnable)
            h.postDelayed(endRunnable, 60_000)
        }
    }

    private fun startSession() {
        sessionStart = SystemClock.elapsedRealtime()
        pings.clear()
        maxTemp = 0f
        minFree = Long.MAX_VALUE
    }

    private fun endSession() {
        if (sessionStart == 0L) return
        val sec = (SystemClock.elapsedRealtime() - sessionStart) / 1000
        if (sec >= 60) {
            val ok = pings.filter { it >= 0 }
            val avg = if (ok.isEmpty()) 0 else ok.sum() / ok.size
            val mx = ok.maxOrNull() ?: 0
            val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
            val ram = if (minFree == Long.MAX_VALUE) 0 else minFree
            SessionLog.append(this, "$date,${sec / 60},$avg,$mx,${fmt1(maxTemp)},$ram")
        }
        sessionStart = 0L
    }

    // ---------- опрос раз в секунду ----------
    private val tick = object : Runnable {
        override fun run() {
            ticks++
            val needSample = panel != null || sessionStart > 0 || widgetText.isNotEmpty()
            if (ticks % 3 == 1 && needSample) sample()
            updateWidgets()
            h.postDelayed(this, 1000)
        }
    }

    private fun sample() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            battery = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
            temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            if (sessionStart > 0 && temp > maxTemp) maxTemp = temp
        }
        freeCache = freeMb()
        if (sessionStart > 0 && freeCache < minFree) minFree = freeCache
        Thread {
            val ms = pingRoblox()
            h.post {
                lastPing = ms
                if (sessionStart > 0) pings.add(ms)
                updateWidgets()
            }
        }.start()
    }

    private fun pingRoblox(): Int {
        val t0 = System.nanoTime()
        return try {
            Socket().use { it.connect(InetSocketAddress("www.roblox.com", 443), 2000) }
            ((System.nanoTime() - t0) / 1_000_000).toInt()
        } catch (e: Exception) {
            -1
        }
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi
    }

    private fun freeMb(): Long = memInfo().availMem / 1048576
    private fun totalMb(): Long = memInfo().totalMem / 1048576

    private fun thermalName(): String = try {
        val s = (getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
        t("th" + s.coerceIn(0, 5))
    } catch (e: Exception) {
        "?"
    }

    private fun refreshHz(): Int = try {
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate?.toInt() ?: 0
    } catch (e: Exception) {
        0
    }

    private fun sessionTime(): String {
        if (sessionStart == 0L) return "0:00:00"
        val s = (SystemClock.elapsedRealtime() - sessionStart) / 1000
        return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun pingText(): String = if (lastPing >= 0) "$lastPing ${t("ms")}" else "—"

    private fun updateWidgets() {
        for ((id, tv) in widgetText) {
            tv.text = when (id) {
                "ping" -> "${t("hud_ping")} ${pingText()}"
                "ram" -> "${t("hud_ram")} $freeCache ${t("mb")}"
                "battery" -> "🔋 $battery% • ${fmt1(temp)}°C"
                "session" -> "⏱ ${sessionTime()}"
                "clock" -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                else -> ""
            }
        }
        infoText?.text = infoString()
    }

    private fun infoString(): String =
        String.format(t("info_ram"), freeCache, totalMb()) + "\n" +
            String.format(t("info_batt"), battery, fmt1(temp)) + "\n" +
            String.format(t("info_therm"), thermalName()) + "\n" +
            String.format(t("info_ping"), pingText()) + "\n" +
            String.format(t("info_screen"), refreshHz()) + "\n" +
            String.format(t("info_session"), if (sessionStart > 0) sessionTime() else t("not_running"))

    // ---------- окна ----------
    private fun addOv(v: View, gravity: Int, flags: Int, w: Int, ht: Int, x: Int, y: Int): Boolean {
        val lp = LP(w, ht, LP.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT).apply {
            this.gravity = gravity
            this.x = x
            this.y = y
        }
        return try {
            wm.addView(v, lp)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun rm(v: View) {
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // уже убрано
        }
    }

    private fun removeAll() {
        for (v in widgets) rm(v)
        widgets.clear()
        widgetText.clear()
        keyViews.clear()
        for (v in fxViews) rm(v)
        fxViews.clear()
    }

    private fun applyAll() {
        removeAll()
        buildFx()
        for (m in Mods.all) if (Mods.on(this, m)) buildMod(m)
        updateWidgets()
    }

    // ---------- эффекты экрана ----------
    private fun addFx(v: View) {
        if (addOv(v, Gravity.TOP or Gravity.START, FULL, LP.MATCH_PARENT, LP.MATCH_PARENT, 0, 0)) fxViews.add(v)
    }

    private fun buildFx() {
        val tint = Cfg.getInt(this, "fx.tint", 0)
        val amt = Cfg.getInt(this, "fx.amt", 40)
        if (tint > 0 && amt > 0) {
            val a = amt * 255 / 100 * 4 / 10
            val v = View(this)
            v.setBackgroundColor(if (tint == 1) Color.argb(a, 255, 150, 40) else Color.argb(a, 70, 120, 255))
            addFx(v)
        }
        val vig = Cfg.getInt(this, "fx.vig", 0)
        if (vig > 0) {
            val dm = resources.displayMetrics
            val v = View(this)
            v.background = GradientDrawable().apply {
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = maxOf(dm.widthPixels, dm.heightPixels) * 0.7f
                setGradientCenter(0.5f, 0.5f)
                colors = intArrayOf(0x00000000, 0x00000000, Color.argb(vig * 255 / 100, 0, 0, 0))
            }
            addFx(v)
        }
        val dim = Cfg.getInt(this, "fx.dim", 0)
        if (dim > 0) {
            val v = View(this)
            v.setBackgroundColor(Color.argb(dim * 255 / 100, 0, 0, 0))
            addFx(v)
        }
    }

    // ---------- моды ----------
    private fun chip(): GradientDrawable = GradientDrawable().apply {
        setColor(0xAA101218.toInt())
        cornerRadius = dp(8).toFloat()
    }

    private fun capBg(on: Boolean): GradientDrawable = GradientDrawable().apply {
        setColor(if (on) accent() else 0xAA101218.toInt())
        cornerRadius = dp(6).toFloat()
    }

    private fun cap(label: String, wDp: Int, s: Float, col: Int): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(col)
        textSize = 12f * s
        background = capBg(false)
        layoutParams = LinearLayout.LayoutParams(dp(wDp * s), dp(36 * s)).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
    }

    private fun buildKeys(s: Float, col: Int): View {
        val w = cap("W", 36, s, col)
        val a = cap("A", 36, s, col)
        val sd = cap("S", 36, s, col)
        val d = cap("D", 36, s, col)
        val sh = cap("Shift", 54, s, col)
        val sp = cap("Space", 90, s, col)
        keyViews[KeyEvent.KEYCODE_W] = w
        keyViews[KeyEvent.KEYCODE_A] = a
        keyViews[KeyEvent.KEYCODE_S] = sd
        keyViews[KeyEvent.KEYCODE_D] = d
        keyViews[KeyEvent.KEYCODE_SHIFT_LEFT] = sh
        keyViews[KeyEvent.KEYCODE_SPACE] = sp
        val ctx = this
        fun rowOf(vararg vs: View): LinearLayout {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            for (v in vs) r.addView(v)
            return r
        }
        val col2 = LinearLayout(this)
        col2.orientation = LinearLayout.VERTICAL
        col2.gravity = Gravity.CENTER_HORIZONTAL
        col2.addView(rowOf(w))
        col2.addView(rowOf(a, sd, d))
        col2.addView(rowOf(sh, sp))
        return col2
    }

    private fun buildMod(m: ModDef) {
        val s = Mods.scale(this, m) / 100f
        val col = Mods.color(this, m)
        val view: View
        if (m.id == "keys") {
            view = buildKeys(s, col)
        } else {
            val tvw = TextView(this)
            tvw.setTextColor(col)
            tvw.textSize = 13f * s
            tvw.setPadding(dp(8 * s), dp(4 * s), dp(8 * s), dp(4 * s))
            tvw.background = chip()
            widgetText[m.id] = tvw
            view = tvw
        }
        view.alpha = Mods.opacity(this, m) / 100f
        val ok = addOv(
            view, Mods.gravity(Mods.anchor(this, m)), PASS,
            LP.WRAP_CONTENT, LP.WRAP_CONTENT,
            dp(Mods.x(this, m)), dp(Mods.y(this, m))
        )
        if (ok) widgets.add(view) else widgetText.remove(m.id)
    }

    // ---------- панель ----------
    fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }

    private fun pbtn(text: String, s: Float, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 13f * s
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(accent())
            cornerRadius = dp(10 * s).toFloat()
        }
        setOnClickListener { onClick() }
    }

    private fun showPanel() {
        if (panel != null) return
        val s = Cfg.getInt(this, "panel.scale", 100) / 100f
        val a = Cfg.getInt(this, "panel.opacity", 92) * 255 / 100
        val base = if (Cfg.amoled(this)) 0x000000 else 0x14161D
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14 * s), dp(12 * s), dp(14 * s), dp(12 * s))
            background = GradientDrawable().apply {
                setColor((a shl 24) or base)
                cornerRadius = dp(14 * s).toFloat()
            }
        }
        box.addView(TextView(this).apply {
            text = "RBX LAUNCHER"
            setTextColor(accent())
            textSize = 15f * s
            setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = Auth.username(this@KeyService)
            setTextColor(0xFF9AA3B2.toInt())
            textSize = 12f * s
        })
        val info = TextView(this).apply {
            setTextColor(0xFFD5DAE3.toInt())
            textSize = 13f * s
            setPadding(0, dp(8 * s), 0, dp(8 * s))
        }
        infoText = info
        box.addView(info)

        box.addView(pbtn(t("boost"), s) { boost() })
        val dim = Cfg.getInt(this, "fx.dim", 0)
        val dimLabel = if (dim == 0) t("off") else "$dim%"
        box.addView(pbtn(String.format(t("dim_btn"), dimLabel), s) {
            val levels = intArrayOf(0, 30, 50, 70)
            val cur = Cfg.getInt(this, "fx.dim", 0)
            Cfg.putInt(this, "fx.dim", levels.firstOrNull { it > cur } ?: 0)
            refresh()
        })
        box.addView(pbtn(String.format(t("close_btn"), Cfg.keyName(Cfg.hotkey(this))), s) { hidePanel() })

        val anchor = Cfg.getInt(this, "panel.anchor", 2)
        if (addOv(box, Mods.gravity(anchor), LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL,
                dp(300 * s), LP.WRAP_CONTENT, dp(12), dp(12))) {
            panel = box
            sample()
            updateWidgets()
        }
    }

    private fun hidePanel() {
        panel?.let { rm(it) }
        panel = null
        infoText = null
    }

    // ---------- освободить ОЗУ ----------
    private fun boost() {
        val before = freeMb()
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val skip = HashSet<String>()
        skip.add(ROBLOX)
        skip.add(packageName)
        skip.add("com.android.systemui")
        skip.add("android")
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.resolveActivity(home, 0)?.activityInfo?.packageName?.let { skip.add(it) }
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')?.let { skip.add(it) }

        var n = 0
        for (a in packageManager.getInstalledApplications(0)) {
            if (a.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            if (a.packageName in skip) continue
            try {
                am.killBackgroundProcesses(a.packageName)
                n++
            } catch (e: Exception) {
                // пропускаем
            }
        }
        h.postDelayed({
            val diff = freeMb() - before
            val sign = if (diff >= 0) "+" else ""
            Toast.makeText(this, String.format(t("boost_done"), n, "$sign$diff"), Toast.LENGTH_LONG).show()
            sample()
        }, 1200)
    }
}

package com.rbx.launcher

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

/** Экран загрузки в стиле Lunar Client: логотип (твоя картинка) и полоса прогресса. */
class SplashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this
        I18n.init(ctx)
        val accent = Cfg.accent(ctx)

        val root = FrameLayout(ctx)
        root.addView(StarsView(ctx))

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val img = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            val bm = Ui.splash(ctx)
            if (bm != null) setImageBitmap(bm) else setImageResource(R.drawable.splash_default)
        }
        col.addView(img, LinearLayout.LayoutParams(Ui.dp(ctx, 240), Ui.dp(ctx, 240)))
        col.addView(Ui.tv(ctx, "RBX LAUNCHER", 24f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.15f
        })
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val total = Ui.dp(ctx, 260)
        val track = FrameLayout(ctx).apply { background = Ui.round(ctx, 0xFF1E2130.toInt(), 4) }
        val fill = View(ctx).apply { background = Ui.round(ctx, accent, 4) }
        track.addView(fill, FrameLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT))

        val bottom = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        bottom.addView(Ui.tv(ctx, I18n.t("loading"), 13f, 0xFF9AA3B2.toInt()))
        bottom.addView(track, LinearLayout.LayoutParams(total, Ui.dp(ctx, 6)).apply { topMargin = Ui.dp(ctx, 10) })
        root.addView(
            bottom,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = Ui.dp(ctx, 48) }
        )
        setContentView(root)
        col.alpha = 0f
        col.scaleX = 0.9f
        col.scaleY = 0.9f
        col.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()

        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            addUpdateListener {
                val lp = fill.layoutParams
                lp.width = (total * (it.animatedValue as Float)).toInt()
                fill.layoutParams = lp
            }
            start()
        }
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(ctx, MainActivity::class.java))
            @Suppress("DEPRECATION")
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2400)
    }
}

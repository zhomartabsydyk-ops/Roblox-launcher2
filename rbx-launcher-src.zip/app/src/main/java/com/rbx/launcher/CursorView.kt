package com.rbx.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * Курсор-прицел поверх игры. Виды: 0 крест, 1 точка, 2 кольцо, 3 кольцо с точкой,
 * 4 косой крест, 5 квадрат, 6 стрелка (остриё в центре), 7 T-образный.
 */
class CursorView(
    ctx: Context,
    private val shape: Int,
    private val thick: Float,
    private val gap: Float,
    color: Int,
    private val outline: Boolean
) : View(ctx) {

    private val main = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = 0xFF000000.toInt()
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        if (outline) render(c, edge, thick + 3f * resources.displayMetrics.density, false)
        render(c, main, thick, true)
    }

    private fun cross(c: Canvas, p: Paint, m: Float, s: Float, pad: Float, top: Boolean) {
        c.drawLine(pad, m, m - gap, m, p)
        c.drawLine(m + gap, m, s - pad, m, p)
        if (top) c.drawLine(m, pad, m, m - gap, p)
        c.drawLine(m, m + gap, m, s - pad, p)
    }

    private fun render(c: Canvas, p: Paint, tw: Float, mainPass: Boolean) {
        val s = width.toFloat()
        val m = s / 2f
        val pad = tw
        p.strokeWidth = tw
        val fillW = if (mainPass) 0f else tw
        when (shape) {
            0 -> {
                p.style = Paint.Style.STROKE
                cross(c, p, m, s, pad, true)
            }
            1 -> {
                p.style = Paint.Style.FILL_AND_STROKE
                p.strokeWidth = fillW
                c.drawCircle(m, m, maxOf(thick * 1.2f, s * 0.1f), p)
            }
            2 -> {
                p.style = Paint.Style.STROKE
                c.drawCircle(m, m, m - tw, p)
            }
            3 -> {
                p.style = Paint.Style.STROKE
                c.drawCircle(m, m, m - tw, p)
                p.style = Paint.Style.FILL_AND_STROKE
                p.strokeWidth = fillW
                c.drawCircle(m, m, maxOf(thick * 1.1f, s * 0.06f), p)
            }
            4 -> {
                p.style = Paint.Style.STROKE
                val d = m - pad
                val g = gap * 0.7f
                c.drawLine(m - d, m - d, m - g, m - g, p)
                c.drawLine(m + g, m + g, m + d, m + d, p)
                c.drawLine(m + d, m - d, m + g, m - g, p)
                c.drawLine(m - g, m + g, m - d, m + d, p)
            }
            5 -> {
                p.style = Paint.Style.STROKE
                c.drawRect(pad, pad, s - pad, s - pad, p)
            }
            6 -> {
                p.style = Paint.Style.FILL_AND_STROKE
                p.strokeWidth = fillW
                val u = m * 0.9f
                val path = Path().apply {
                    moveTo(m, m)
                    lineTo(m, m + u)
                    lineTo(m + 0.26f * u, m + 0.76f * u)
                    lineTo(m + 0.45f * u, m + 1.1f * u)
                    lineTo(m + 0.60f * u, m + 1.03f * u)
                    lineTo(m + 0.42f * u, m + 0.70f * u)
                    lineTo(m + 0.74f * u, m + 0.70f * u)
                    close()
                }
                c.drawPath(path, p)
            }
            else -> {
                p.style = Paint.Style.STROKE
                cross(c, p, m, s, pad, false)
            }
        }
    }
}
